========================================
VOOP BASKETBALL ANALYTICS
========================================

INSTALLATION (3 steps):

1. Double-click "install.command"
2. Grant camera permission when prompted
3. Double-click "Voop.app"

HOW TO USE:
- Click START CAMERA
- Click LEARN HOME TEAM, click 5 home players
- Click LEARN AWAY TEAM, click 5 away players

SHORTCUTS:
H = Flip attack direction
R = Generate timeout report
Q = Quit

TROUBLESHOOTING:
No camera? Go to System Settings → Privacy & Security → Camera
========================================
