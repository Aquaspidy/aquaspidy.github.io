import sys
import os
import json
import base64
import cv2
import numpy as np
from collections import deque
import time
from PyQt6.QtWidgets import (QApplication, QMainWindow, QLabel, QPushButton, 
                             QVBoxLayout, QHBoxLayout, QWidget, QFormLayout, 
                             QLineEdit, QGroupBox, QMessageBox, QStatusBar,
                             QFileDialog, QCheckBox)
from PyQt6.QtCore import QThread, pyqtSignal, Qt, QUrl, QTimer
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWebEngineWidgets import QWebEngineView

from varsity_logic import AppConfig, VarsityAIEngine, normalize_lighting
from camera_window import CameraWindow
from camera_manager import CameraManager
from performance import PerformanceTracker
from report_generator import ReportGenerator
from enhanced_events import EnhancedEventDetector
from tactical_recognition import TacticalDetector
from heatmap import HeatmapGenerator
from shot_quality_3d import ShotQuality3D
import gc

os.chdir(os.path.dirname(os.path.abspath(__file__)))

class SimpleColorMatcher:
    """Simple RGB color matcher - works like the original app.py"""
    
    def __init__(self):
        self.home_color = None
        self.away_color = None
        self.home_samples = []
        self.away_samples = []
        self.learning = False
        self.learning_team = None
        
    def start_learning(self, team):
        self.learning = True
        self.learning_team = team
        if team == 'home':
            self.home_samples = []
        else:
            self.away_samples = []
    
    def add_sample(self, rgb_color):
        if self.learning_team == 'home':
            self.home_samples.append(rgb_color)
            if len(self.home_samples) == 5:
                self.home_color = tuple(np.mean(self.home_samples, axis=0).astype(int))
            return len(self.home_samples)
        else:
            self.away_samples.append(rgb_color)
            if len(self.away_samples) == 5:
                self.away_color = tuple(np.mean(self.away_samples, axis=0).astype(int))
            return len(self.away_samples)
    
    def match(self, rgb_color):
        if self.home_color is None or self.away_color is None:
            print(f"[Matcher] Not ready - home: {self.home_color}, away: {self.away_color}")
            return "Unknown"
        
        dist_to_home = sum((c1 - c2)**2 for c1, c2 in zip(rgb_color, self.home_color))
        dist_to_away = sum((c1 - c2)**2 for c1, c2 in zip(rgb_color, self.away_color))
        THRESHOLD = 1600
        
        print(f"[Matcher] RGB: {rgb_color}, Home: {self.home_color}, Away: {self.away_color}")
        print(f"[Matcher] dist_to_home: {dist_to_home}, dist_to_away: {dist_to_away}")
        
        if dist_to_home < THRESHOLD and dist_to_home < dist_to_away:
            print("[Matcher] -> Home")
            return "Home"
        elif dist_to_away < THRESHOLD and dist_to_away < dist_to_home:
            print("[Matcher] -> Away")
            return "Away"
        print("[Matcher] -> Unknown")
        return "Unknown"
    
    def is_ready(self):
        return self.home_color is not None and self.away_color is not None

class VideoProcessor(QThread):
    frame_ready = pyqtSignal(object)      # For HTML Dashboard
    camera_frame = pyqtSignal(object)     # For Camera Window (raw frame)
    camera_status = pyqtSignal(str)       # For Camera Window status
    status_update = pyqtSignal(str)
    error_occurred = pyqtSignal(str)
    learning_update = pyqtSignal(str, int)
    learning_complete = pyqtSignal(str)
    
    def __init__(self, config, video_path=None, loop_video=False):
        super().__init__()
        self.config = config
        self.running = True
        self.cap = None
        
        # Create matcher FIRST
        self.matcher = SimpleColorMatcher()
        
        # Then create engine and pass matcher
        self.engine = VarsityAIEngine(config)
        self.engine.set_matcher(self.matcher)
        
        self.learning_active = False
        self.learning_team = None
        self.video_path = video_path
        self.loop_video = loop_video
        self.fps = 0
        self.frame_count = 0
        self.start_time = time.time()
        self.performance = PerformanceTracker(fps=30)
        self.event_detector = EnhancedEventDetector(fps=30)
        self.tactic_detector = TacticalDetector()
        self.heatmap = HeatmapGenerator(
            court_width=self.config.frame_width,
            court_height=self.config.frame_height,
            history_frames=300
        )

        self.shot_quality_3d = ShotQuality3D()
    
        self.triangulator = None
        
    def setup(self):
        try:
            if not self.engine._init_model():
                self.error_occurred.emit("Failed to load YOLO model")
                return False
            
            if self.video_path:
                self.cap = cv2.VideoCapture(self.video_path)
                if not self.cap.isOpened():
                    self.error_occurred.emit(f"Cannot open video: {self.video_path}")
                    return False
                self.status_update.emit(f"Playing: {os.path.basename(self.video_path)}")
            else:
                for cam_id in [0, 1]:
                    self.cap = cv2.VideoCapture(cam_id)
                    if self.cap.isOpened():
                        self.config.camera_id = cam_id
                        break
                
                if not self.cap or not self.cap.isOpened():
                    self.error_occurred.emit("Cannot open camera")
                    return False
            
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.frame_width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.frame_height)
            
            if self.engine.court_calibrator.court_polygon is None:
                self.engine.court_calibrator.court_polygon = np.array([
                    [0, 0],
                    [self.config.frame_width, 0],
                    [self.config.frame_width, self.config.frame_height],
                    [0, self.config.frame_height]
                ], dtype=np.int32)
            
            return True
        except Exception as e:
            self.error_occurred.emit(str(e))
            return False
    
    def start_learning(self, team):
        self.learning_active = True
        self.learning_team = team
        self.matcher.start_learning(team)  # USE SIMPLECOLORMATCHER
        self.camera_status.emit(f"🎨 Click on {team} team jerseys (5 clicks)")
        self.status_update.emit(f"Click on {team} team jerseys (5 clicks)")
    
    def process_click(self, x, y, label_w, label_h):
        if not self.matcher.learning or not hasattr(self.engine, 'current_frame'):
            return
        
        frame = self.engine.current_frame
        if frame is None:
            return
        
        scale_x = self.config.frame_width / label_w
        scale_y = self.config.frame_height / label_h
        fx = int(x * scale_x)
        fy = int(y * scale_y)
        fx = max(0, min(fx, self.config.frame_width - 1))
        fy = max(0, min(fy, self.config.frame_height - 1))
        
        results = self.engine.model(frame, classes=[0], conf=0.4, verbose=False)
        
        if results[0].boxes is not None:
            boxes = results[0].boxes.xyxy.cpu().numpy().astype(int)
            for box in boxes:
                x1, y1, x2, y2 = box
                if x1 <= fx <= x2 and y1 <= fy <= y2:
                    rgb = self.get_jersey_rgb(frame, box)
                    if rgb:
                        print(f"[Learning] Clicked RGB: {rgb}")  # <-- ADD THIS
                        count = self.matcher.add_sample(rgb)
                        team = self.matcher.learning_team
                        self.learning_update.emit(team, count)
                        print(f"[Learning] Added sample {count}/5 for {team}")  # <-- ADD THIS
                        if count >= 5:
                            self.matcher.learning = False
                            self.learning_active = False
                            print(f"[Learning] {team} COMPLETE! Colors: {self.matcher.home_color if team == 'home' else self.matcher.away_color}")  # <-- ADD THIS
                            self.learning_complete.emit(team)
                        return
    
    def get_jersey_rgb(self, frame, box):
        """Extract RGB color from jersey center - from original app.py"""
        x1, y1, x2, y2 = box
        h = y2 - y1
        jersey_y1 = y1 + int(h * 0.35)
        jersey_y2 = y1 + int(h * 0.65)
        jersey_x1 = x1 + int((x2 - x1) * 0.3)
        jersey_x2 = x2 - int((x2 - x1) * 0.3)
        
        jersey_y1 = max(0, jersey_y1)
        jersey_y2 = min(frame.shape[0], jersey_y2)
        jersey_x1 = max(0, jersey_x1)
        jersey_x2 = min(frame.shape[1], jersey_x2)
        
        if jersey_y2 <= jersey_y1 or jersey_x2 <= jersey_x1:
            return None
        
        jersey = frame[jersey_y1:jersey_y2, jersey_x1:jersey_x2]
        if jersey.size == 0:
            return None
        
        b, g, r = cv2.split(jersey)
        return (int(np.median(r)), int(np.median(g)), int(np.median(b)))
    
    def encode_frame_to_base64(self, frame):
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 50])
        return base64.b64encode(buffer).decode('utf-8')
    
    def run(self):
        if not self.setup():
            return
        
        self.status_update.emit("Ready - Click LEARN buttons to start")
        
        for _ in range(10):
            self.cap.read()
        
        frame_count = 0
        SKIP_DETECTION = 5
        
        t1_range = ([0, 0, 0], [0, 0, 0])
        t2_range = ([0, 0, 0], [0, 0, 0])
        
        cached_westy = []
        cached_opp = []
        cached_cam_dx = 0
        cached_cam_dy = 0
        
        frame_times = deque(maxlen=30)
        
        while self.running and self.cap.isOpened():
            ret, frame = self.cap.read()
            
            if not ret:
                if self.video_path and self.loop_video:
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ret, frame = self.cap.read()
                    if not ret:
                        time.sleep(0.01)
                        continue
                else:
                    break
            
            frame_start = time.time()
            
            frame = cv2.resize(frame, (self.config.frame_width, self.config.frame_height))
            frame = normalize_lighting(frame)
            
            self.engine.current_frame = frame.copy()
            height, width = frame.shape[:2]
            
            # Run detection
            if frame_count % SKIP_DETECTION == 0:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                y_cutoff = int(height * 0.22)
                
                cam_dx, cam_dy = self.engine.flow_tracker.update(gray, frame_count, y_cutoff)
                cached_cam_dx, cached_cam_dy = cam_dx, cam_dy
                
                westy_players, opp_players, pack_momentum = self.engine._process_detections(
                    frame, frame_count, t1_range, t2_range
                )
                ball_pos = self.engine.ball_position

                self.engine.detection_frame = frame.copy()
            
                        # === UPDATE HEATMAP ===
            # === UPDATE HEATMAP ===
            if hasattr(self.engine, 'tracked_players'):
                for pid, pdata in self.engine.tracked_players.items():
                    if pdata.get('last_box'):
                        x1, y1, x2, y2 = pdata['last_box']
                        cx = (x1 + x2) // 2
                        cy = (y1 + y2) // 2
                        
                        # Get RGB and match
                        box = [x1, y1, x2, y2]
                        rgb = self.get_jersey_rgb(self.engine.detection_frame, box)
                        
                        if rgb and self.matcher.is_ready():
                            result = self.matcher.match(rgb)
                            
                            # ===== CRITICAL FIX =====
                            # Explicitly map result to heatmap team
                            if result == "Home":
                                heatmap_team = "home"  # Use lowercase 'home'
                                print(f"[Heatmap] Player {pid}: {result} → adding to '{heatmap_team}'")
                                self.heatmap.update([{'id': pid, 'x': cx, 'y': cy}], heatmap_team)
                            elif result == "Away":
                                heatmap_team = "away"  # Use lowercase 'away'
                                print(f"[Heatmap] Player {pid}: {result} → adding to '{heatmap_team}'")
                                self.heatmap.update([{'id': pid, 'x': cx, 'y': cy}], heatmap_team)
                            else:
                                print(f"[Heatmap] Player {pid}: {result} → SKIPPED")

            # Clear old players from heatmap
            if frame_count % 50 == 0:
                active_ids = set(self.engine.tracked_players.keys())
                for pid in list(self.heatmap.player_history.keys()):
                    if pid not in active_ids:
                        del self.heatmap.player_history[pid]
                                
                # === UPDATE PERFORMANCE METRICS ===
            # Update performance using tracked_players
            if frame_count % 3 == 0 and hasattr(self.engine, 'tracked_players'):
                for pid, pdata in self.engine.tracked_players.items():
                    if pdata.get('last_box'):
                        x1, y1, x2, y2 = pdata['last_box']
                        cx = (x1 + x2) // 2
                        cy = (y1 + y2) // 2
                        x_m = (cx / width) * 28
                        y_m = (cy / height) * 15
                        
                        # Determine team
                        team = pdata.get('team_locked', 'Unknown')
                        if team == "Westy":
                            self.performance.update_player(pid, x_m, y_m, 'home')
                        elif team == "Opponent":
                            self.performance.update_player(pid, x_m, y_m, 'away')
                        else:
                            # Unknown player - use matcher to determine
                            if self.matcher.is_ready():
                                box = [x1, y1, x2, y2]
                                rgb = self.get_jersey_rgb(self.engine.detection_frame, box)
                                if rgb:
                                    result = self.matcher.match(rgb)
                                    if result == "Home":
                                        self.performance.update_player(pid, x_m, y_m, 'home')
                                    elif result == "Away":
                                        self.performance.update_player(pid, x_m, y_m, 'away')


            possession = self.engine.possession.current_possession
            if possession == "Westy":
                self.performance.update_possession('home')
            elif possession == "Opponent":
                self.performance.update_possession('away')

            all_stats = self.performance.get_all_stats()
            if all_stats.get('total_players', 0) > 0:
                print(f"[Performance] Tracking {all_stats['total_players']} players")
                
                adjusted_momentum = [m - cam_dx for m in pack_momentum]
                self.engine.possession.update(adjusted_momentum, self.engine.possession.westy_attacks_right)
                
                if self.engine.possession.current_possession == "Westy" and westy_players and frame_count % 15 == 0:
                    avg_qsq = np.mean([p.get('qsq', 50) for p in westy_players])
                    self.engine.scout.log_shot_quality(avg_qsq)
                
                # DO NOT UPDATE CACHE HERE - wait until after override
                
            else:
                westy_players = cached_westy
                opp_players = cached_opp
                cam_dx, cam_dy = cached_cam_dx, cached_cam_dy

            # === OVERRIDE TEAM COLORS ===
            if self.matcher.is_ready():
                new_westy = []
                new_opp = []
                
                for p in westy_players:
                    rgb = self.get_jersey_rgb(self.engine.current_frame, p['box'])
                    if rgb:
                        team = self.matcher.match(rgb)
                        if team == "Home":
                            p['team'] = "Westy"
                            new_westy.append(p)
                        elif team == "Away":
                            p['team'] = "Opponent"
                            new_opp.append(p)
                        else:
                            p['team'] = "Unknown"
                            new_westy.append(p)
                    else:
                        new_westy.append(p)
                
                for p in opp_players:
                    rgb = self.get_jersey_rgb(self.engine.current_frame, p['box'])
                    if rgb:
                        team = self.matcher.match(rgb)
                        if team == "Home":
                            p['team'] = "Westy"
                            new_westy.append(p)
                        elif team == "Away":
                            p['team'] = "Opponent"
                            new_opp.append(p)
                        else:
                            new_opp.append(p)
                    else:
                        new_opp.append(p)
                
                # UPDATE THE CACHE WITH THE OVERRIDDEN VALUES
                cached_westy = new_westy
                cached_opp = new_opp
                westy_players = new_westy
                opp_players = new_opp

            
            # === DRAW BOXES DIRECTLY USING THE MATCHER ===
        # Get the raw frame for color extraction
            raw_frame = self.engine.detection_frame if hasattr(self.engine, 'detection_frame') else None
            if raw_frame is not None and hasattr(self.engine, 'tracked_players'):
                for pid, pdata in self.engine.tracked_players.items():
                    if pdata.get('last_box'):
                        x1, y1, x2, y2 = pdata['last_box']
                        box = [x1, y1, x2, y2]
                        
                        # Get RGB and match
                        rgb = self.get_jersey_rgb(raw_frame, box)
                        
                        if rgb and self.matcher.is_ready():
                            team = self.matcher.match(rgb)
                            print(f"[Draw] Player {pid} matched as: {team}")
                            if team == "Home":
                                color = (0, 255, 255)  # Yellow
                                label = f"Home {pid}"
                            elif team == "Away":
                                color = (0, 0, 255)    # Red
                                label = f"Away {pid}"
                            else:
                                team = "Unknown"       # <-- ADD THIS
                                color = (100, 100, 100)  # Gray
                                label = f"Player {pid}"
                        else:
                            team = "Unknown"           # <-- ADD THIS
                            color = (100, 100, 100)  # Gray
                            label = f"Player {pid}"
                        
                        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                        cv2.putText(frame, label, (x1, y1-10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
                
            # === DETECT ENHANCED EVENTS ===
            if frame_count % 20 == 0:  # Check every 10 frames (was 2)
                events = self.event_detector.update(
                    westy_players, 
                    opp_players, 
                    ball_pos=ball_pos,
                    possession=self.engine.possession.current_possession
                )
                
                # Print new events to terminal
                for e in events:
                    print(f"[Event] {e.type} at {e.time:.1f}s: {e.detail}")

                # === 3D SHOT QUALITY DETECTION ===
                if hasattr(self, 'shot_quality_3d') and ball_pos:
                    # Check each tracked player
                    for pid, pdata in self.engine.tracked_players.items():
                        if pdata.get('last_box'):
                            x1, y1, x2, y2 = pdata['last_box']
                            cx = (x1 + x2) // 2
                            cy = (y1 + y2) // 2
                            
                            # Check if this player has the ball (ball near player)
                            ball_dist = np.sqrt((cx - ball_pos[0])**2 + (cy - ball_pos[1])**2)
                            if ball_dist < 60:  # Player has ball (within 60 pixels)
                                # Determine which team this player is on
                                team = pdata.get('team_locked', 'Unknown')
                                if team == "Unknown":
                                    # Try to get team from matcher
                                    if self.matcher.is_ready():
                                        box = [x1, y1, x2, y2]
                                        rgb = self.get_jersey_rgb(self.engine.detection_frame, box)
                                        if rgb:
                                            result = self.matcher.match(rgb)
                                            if result == "Home":
                                                team = "Westy"
                                            elif result == "Away":
                                                team = "Opponent"
                                
                                # Detect shot attempt
                                shot = self.shot_quality_3d.detect_shot_attempt(
                                    player_id=pid,
                                    position_2d=(cx, cy),
                                    ball_position=ball_pos,
                                    defenders=opp_players if team == "Westy" else westy_players,
                                    frame=frame
                                )
                                if shot:
                                    print(f"[Shot 3D] Player {pid} shot quality: {shot.shot_quality:.1f}% (distance: {shot.distance_to_hoop:.1f}m)")

            # === TACTICAL RECOGNITION ===
            if frame_count % 25 == 0:  # Check every 15 frames (was 3)
                tactics = self.tactic_detector.update(
                    westy_players, 
                    opp_players, 
                    possession=self.engine.possession.current_possession
                )
                
                # Print new tactics to terminal
                for t in tactics:
                    print(f"[Tactic] {t.name} ({t.type}) - {t.description} (conf: {t.confidence:.0%})")
                
            # === BALL TRACKING ===
            if hasattr(self.engine, 'ball_tracking_active') and self.engine.ball_tracking_active:
                if self.engine.ball_color_mean is not None:
                    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                    
                    # Create mask based on learned color
                    lower = np.maximum(self.engine.ball_color_mean - self.engine.ball_color_std * 1.5, [0, 50, 50])
                    upper = np.minimum(self.engine.ball_color_mean + self.engine.ball_color_std * 1.5, [180, 255, 255])
                    mask = cv2.inRange(hsv, lower.astype(np.uint8), upper.astype(np.uint8))
                    
                    # Find contours
                    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    
                    # Keep the last ball position
                    last_pos = self.engine.ball_position
                    best_contour = None
                    best_dist = float('inf')
                    
                    for cnt in contours:
                        area = cv2.contourArea(cnt)
                        if 50 < area < 2000:
                            M = cv2.moments(cnt)
                            if M['m00'] != 0:
                                cx = int(M['m10'] / M['m00'])
                                cy = int(M['m01'] / M['m00'])
                                
                                # If we have a last position, choose closest
                                if last_pos:
                                    dist = np.sqrt((cx - last_pos[0])**2 + (cy - last_pos[1])**2)
                                    if dist < best_dist:
                                        best_dist = dist
                                        best_contour = cnt
                                else:
                                    # First detection - take the largest
                                    if area > 100:
                                        best_contour = cnt
                                        break
                    
                    # If no contour found but we had a last position, look for any
                    if best_contour is None and last_pos is not None:
                        for cnt in contours:
                            area = cv2.contourArea(cnt)
                            if 50 < area < 2000:
                                best_contour = cnt
                                break
                    
                    if best_contour is not None:
                        M = cv2.moments(best_contour)
                        if M['m00'] != 0:
                            cx = int(M['m10'] / M['m00'])
                            cy = int(M['m01'] / M['m00'])
                            self.engine.ball_position = (cx, cy)
                            
                            # Draw ball on frame
                            cv2.circle(frame, (cx, cy), 10, (255, 255, 255), 2)
                            cv2.circle(frame, (cx, cy), 12, (0, 255, 255), 1)
                            cv2.putText(frame, "BALL", (cx - 20, cy - 20), 
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            self.camera_frame.emit(frame)
            
            offensive_players = westy_players if self.engine.possession.current_possession == "Westy" else opp_players
            self.engine._detect_pick_and_roll(frame, offensive_players)
            self.engine._detect_mismatches(frame, westy_players, opp_players, frame_count)
            self.engine._detect_cramping(frame, westy_players, width, height, frame_count)
            
            defending_team = opp_players if self.engine.possession.current_possession == "Westy" else westy_players
            self.engine._detect_defensive_shell(frame, defending_team, self.engine.possession.current_possession)
            
            self.engine._draw_hud(frame)
            
            # Learning overlay on the frame (for display)
            if self.learning_active:
                detector = self.engine.player_tracker.color_detector
                overlay = frame.copy()
                cv2.rectangle(overlay, (0, 0), (width, 60), (0, 0, 0), -1)
                frame = cv2.addWeighted(overlay, 0.6, frame, 0.4, 0)
                count = len(detector.home_samples) if self.learning_team == 'home' else len(detector.away_samples)
                cv2.putText(frame, f"LEARNING {self.learning_team.upper()} - Click jerseys ({count}/5)", 
                           (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            
            detector = self.engine.player_tracker.color_detector
            home_status = "✅ Home: Learned" if detector.home_learned else f"Home: {len(detector.home_samples)}/5"
            away_status = "✅ Away: Learned" if detector.away_learned else f"Away: {len(detector.away_samples)}/5"
            cv2.putText(frame, home_status, (width - 180, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
            cv2.putText(frame, away_status, (width - 180, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
            
            # Encode frame for HTML
            frame_base64 = self.encode_frame_to_base64(frame)
            
            # Calculate FPS
            frame_times.append(time.time() - frame_start)
            if len(frame_times) > 5:
                self.fps = 1.0 / np.mean(frame_times)
            
            # Build data package for HTML Dashboard
            data = self.build_data_package(
                frame_base64, 
                westy_players, 
                opp_players,
                width,
                height,
                frame_count
            )
            
            self.frame_ready.emit(data)
            frame_count += 1
            
            # Force garbage collection every 30 frames
            if frame_count % 30 == 0:
                gc.collect()
            
            # Limit to 30 FPS
            elapsed = time.time() - frame_start
            if elapsed < 0.033:
                time.sleep(0.033 - elapsed)
        
        # ===== END OF WHILE LOOP =====
        
        if self.cap:
            self.cap.release()
    
    def build_data_package(self, frame_base64, westy_players, opp_players, width, height, frame_count):
        """Build data package for HTML Dashboard"""
        detector = self.engine.player_tracker.color_detector
        possession = self.engine.possession.current_possession
        possession_percent = int(self.engine.possession.get_momentum_percentage() * 0.5 + 50)
        possession_percent = max(0, min(100, possession_percent))

        ball_pos = self.engine.ball_position
        ball_data = None
        if ball_pos:
            ball_data = {
                'x': (ball_pos[0] / width) * 100,
                'y': (ball_pos[1] / height) * 100
            }
        
        event_summary = self.event_detector.get_event_summary()
        recent_events = self.event_detector.get_events()[-8:]  # Get last 8 events
        event_types = []
        for e in recent_events:
            event_types.append({
                'type': e.type,
                'time': e.time,
                'team': e.team,
                'detail': e.detail
            })

        # Get event counts from last 50 events
        all_events = self.event_detector.get_events()[-50:]
        event_counts = {
            'shots': sum(1 for ev in all_events if ev.type == 'Shot'),
            'screens': sum(1 for ev in all_events if ev.type == 'Screen'),
            'fastbreaks': sum(1 for ev in all_events if ev.type == 'Fastbreak'),
            'turnovers': sum(1 for ev in all_events if ev.type == 'Turnover'),
            'steals': sum(1 for ev in all_events if ev.type == 'Steal'),
            'mismatches': sum(1 for ev in all_events if ev.type == 'Mismatch'),
            'threePM': sum(1 for ev in all_events if ev.type == '3PT Made'),
            'layupM': sum(1 for ev in all_events if ev.type == 'Layup Made'),
        }

        # === GET TACTICS ===
        tactics = self.tactic_detector.get_current_tactics()
        tactic_list = []
        for t in tactics:
            tactic_list.append({
                'name': t.name,
                'type': t.type,
                'confidence': round(t.confidence * 100, 1),
                'description': t.description,
                'counter': t.counter
            })

        # === GENERATE HEATMAPS ===
        home_heatmap = self.heatmap.generate_heatmap(team='home')
        away_heatmap = self.heatmap.generate_heatmap(team='away')
        top_players = self.heatmap.get_top_players(5)

        # Debug - print the actual data counts
        home_count = self.heatmap.get_team_activity('home')
        away_count = self.heatmap.get_team_activity('away')
        print(f"[Heatmap Build] Home positions: {home_count}")
        print(f"[Heatmap Build] Away positions: {away_count}")

        # Define encode_heatmap INSIDE build_data_package
        def encode_heatmap(heatmap, team_name):
            """Encode heatmap with team name for debugging"""
            if heatmap is None:
                print(f"[Heatmap Encode] {team_name} heatmap is None")
                return None
            
            # Check if heatmap has any data
            if np.max(heatmap) == 0:
                print(f"[Heatmap Encode] {team_name} heatmap is empty (all zeros)")
            else:
                print(f"[Heatmap Encode] {team_name} heatmap has data - max value: {np.max(heatmap)}")
            
            # Try to load court image
            court_img_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'halfcourtpic.png')
            court_img = cv2.imread(court_img_path)
            
            # If not found, create a simple dark background
            if court_img is None:
                court_img = np.zeros((height, width, 3), dtype=np.uint8)
                court_img[:, :] = [30, 30, 40]
            else:
                # Convert BGR to RGB to fix purple tint (OpenCV loads as BGR)
                court_img = cv2.cvtColor(court_img, cv2.COLOR_BGR2RGB)
                
                # Get original dimensions
                orig_h, orig_w = court_img.shape[:2]
                
                # Calculate aspect ratio preserving resize
                target_w = width
                target_h = height
                
                # Calculate scaling to fit while preserving aspect ratio
                scale_w = target_w / orig_w
                scale_h = target_h / orig_h
                scale = min(scale_w, scale_h)  # Use the smaller scale to fit entirely
                
                # Calculate new dimensions
                new_w = int(orig_w * scale)
                new_h = int(orig_h * scale)
                
                # Resize preserving aspect ratio
                court_resized = cv2.resize(court_img, (new_w, new_h), interpolation=cv2.INTER_AREA)
                
                # Create canvas and center the image
                canvas = np.zeros((target_h, target_w, 3), dtype=np.uint8)
                canvas[:, :] = [30, 30, 40]  # Dark background
                
                # Center the resized image on canvas
                x_offset = (target_w - new_w) // 2
                y_offset = (target_h - new_h) // 2
                canvas[y_offset:y_offset+new_h, x_offset:x_offset+new_w] = court_resized
                
                court_resized = canvas
            
            # Resize heatmap to match
            heatmap_resized = cv2.resize(heatmap, (width, height))
            heatmap_color = cv2.applyColorMap((heatmap_resized * 255).astype(np.uint8), cv2.COLORMAP_JET)
            
            # Overlay heatmap on court image
            overlay = cv2.addWeighted(court_resized, 0.4, heatmap_color, 0.6, 0)
            
            _, buffer = cv2.imencode('.png', overlay)
            return base64.b64encode(buffer).decode('utf-8')

        home_heatmap_b64 = encode_heatmap(home_heatmap, "HOME")
        away_heatmap_b64 = encode_heatmap(away_heatmap, "AWAY")

        # === USE TRACKED_PLAYERS FOR POSITIONS ===
        home_players = []
        away_players = []

        # Create smoothing buffer if it doesn't exist
        if not hasattr(self, '_smooth_positions'):
            self._smooth_positions = {}

        if hasattr(self.engine, 'tracked_players'):
            for pid, pdata in self.engine.tracked_players.items():
                if pdata.get('last_box'):
                    x1, y1, x2, y2 = pdata['last_box']
                    cx = (x1 + x2) // 2
                    cy = (y1 + y2) // 2
                    
                    # ===== SMOOTHING =====
                    # Exponential moving average - 70% new, 30% old
                    if pid not in self._smooth_positions:
                        self._smooth_positions[pid] = {'x': cx, 'y': cy}
                    else:
                        alpha = 0.7  # Higher = faster response, Lower = smoother
                        self._smooth_positions[pid]['x'] = int(alpha * cx + (1 - alpha) * self._smooth_positions[pid]['x'])
                        self._smooth_positions[pid]['y'] = int(alpha * cy + (1 - alpha) * self._smooth_positions[pid]['y'])
                    
                    smooth_x = self._smooth_positions[pid]['x']
                    smooth_y = self._smooth_positions[pid]['y']
                    # ===== END SMOOTHING =====
                    
                    # Determine team
                    team = "Unknown"
                    if self.matcher.is_ready():
                        box = [x1, y1, x2, y2]
                        rgb = self.get_jersey_rgb(self.engine.detection_frame, box)
                        if rgb:
                            match_result = self.matcher.match(rgb)
                            if match_result == "Home":
                                team = "Westy"
                            elif match_result == "Away":
                                team = "Opponent"
                    
                    # If matcher not ready, try team_locked
                    if team == "Unknown":
                        team = pdata.get('team_locked', 'Unknown')
                    
                    # Get speed
                    speed = 0
                    stats = self.performance.get_player_stats(pid)
                    if stats:
                        speed = stats.get('avg_speed', 0)
                    
                    player_data = {
                        'id': pid,
                        'x': (smooth_x / width) * 100,  # Use smoothed position
                        'y': (smooth_y / height) * 100,  # Use smoothed position
                        'hasBall': False,
                        'speed': round(speed, 1)
                    }
                    
                    # Add to appropriate team
                    if team == "Westy" or team == "Home":
                        home_players.append(player_data)
                    elif team == "Opponent" or team == "Away":
                        away_players.append(player_data)

        # === GET MATCHUP (Player with Ball + Defender) ===
        ball_player_id = None
        ball_player_team = None
        ball_player_pos = None
        closest_defender_id = None
        closest_defender_pos = None
        closest_defender_team = None
        mismatch_detected = None
        
        # Step 1: Find which player has the ball
        if ball_pos and hasattr(self.engine, 'tracked_players'):
            ball_x, ball_y = ball_pos
            closest_to_ball = None
            closest_dist = float('inf')
            
            for pid, pdata in self.engine.tracked_players.items():
                if pdata.get('last_box'):
                    x1, y1, x2, y2 = pdata['last_box']
                    cx = (x1 + x2) // 2
                    cy = (y1 + y2) // 2
                    
                    # Distance from player to ball
                    dist = np.sqrt((cx - ball_x)**2 + (cy - ball_y)**2)
                    if dist < closest_dist and dist < 80:  # Within 80 pixels of ball
                        closest_dist = dist
                        closest_to_ball = pid
                        ball_player_pos = (cx, cy)
            
            if closest_to_ball is not None:
                ball_player_id = closest_to_ball
                # Get team of ball player
                ball_player_team = self.engine.tracked_players[closest_to_ball].get('team_locked', 'Unknown')
                if ball_player_team == "Unknown":
                    # Try matcher
                    if self.matcher.is_ready():
                        box = self.engine.tracked_players[closest_to_ball]['last_box']
                        rgb = self.get_jersey_rgb(self.engine.detection_frame, box)
                        if rgb:
                            result = self.matcher.match(rgb)
                            if result == "Home":
                                ball_player_team = "Westy"
                            elif result == "Away":
                                ball_player_team = "Opponent"
                
                # Step 2: Find closest defender (opponent nearest to ball player)
                if ball_player_pos and ball_player_team != "Unknown":
                    closest_def_dist = float('inf')
                    
                    for pid, pdata in self.engine.tracked_players.items():
                        if pid == ball_player_id:
                            continue
                        if pdata.get('last_box'):
                            x1, y1, x2, y2 = pdata['last_box']
                            cx = (x1 + x2) // 2
                            cy = (y1 + y2) // 2
                            
                            # Get team of this player
                            player_team = pdata.get('team_locked', 'Unknown')
                            if player_team == "Unknown" and self.matcher.is_ready():
                                box = [x1, y1, x2, y2]
                                rgb = self.get_jersey_rgb(self.engine.detection_frame, box)
                                if rgb:
                                    result = self.matcher.match(rgb)
                                    if result == "Home":
                                        player_team = "Westy"
                                    elif result == "Away":
                                        player_team = "Opponent"
                            
                            # Only consider opponents
                            if player_team != ball_player_team and player_team != "Unknown":
                                dist = np.sqrt((cx - ball_player_pos[0])**2 + (cy - ball_player_pos[1])**2)
                                if dist < closest_def_dist and dist < 150:  # Within 150 pixels
                                    closest_def_dist = dist
                                    closest_defender_id = pid
                                    closest_defender_pos = (cx, cy)
                                    closest_defender_team = player_team
                    
                    # Step 3: Check for mismatch (height difference)
                    if closest_defender_id is not None and ball_player_id is not None:
                        # Get box heights
                        ball_box = self.engine.tracked_players[ball_player_id]['last_box']
                        def_box = self.engine.tracked_players[closest_defender_id]['last_box']
                        
                        ball_height = ball_box[3] - ball_box[1]  # y2 - y1
                        def_height = def_box[3] - def_box[1]
                        
                        if ball_height > 0 and def_height > 0:
                            height_ratio = ball_height / def_height
                            
                            # Mismatch if one player is significantly taller
                            if height_ratio > 1.2 or height_ratio < 0.8:
                                mismatch_detected = {
                                    'player1': ball_player_id,
                                    'player2': closest_defender_id,
                                    'ratio': round(height_ratio, 2),
                                    'distance': round(closest_def_dist, 1),
                                    'advantage': 'home' if height_ratio > 1.2 else 'away'
                                }
        
        # Get stats for ball player and defender
        ball_player_stats = {}
        defender_stats = {}
        
        if ball_player_id is not None:
            stats = self.performance.get_player_stats(ball_player_id)
            if stats:
                ball_player_stats = {
                    'id': ball_player_id,
                    'team': ball_player_team,
                    'speed': stats.get('avg_speed', 0),
                    'distance': stats.get('total_distance', 0),
                    'sprints': stats.get('sprints', 0),
                    'fatigue': stats.get('fatigue', 0),
                    'has_ball': True
                }
        
        if closest_defender_id is not None:
            stats = self.performance.get_player_stats(closest_defender_id)
            if stats:
                defender_stats = {
                    'id': closest_defender_id,
                    'team': closest_defender_team,
                    'speed': stats.get('avg_speed', 0),
                    'distance': stats.get('total_distance', 0),
                    'sprints': stats.get('sprints', 0),
                    'fatigue': stats.get('fatigue', 0),
                    'is_defender': True
                }
        
        # ================================================================
        # ===== END OF MATCHUP CODE =====
        # ================================================================

        pnr_count = len(self.engine.active_pnrs) if hasattr(self.engine, 'active_pnrs') else 0

        return {
            'videoFrame': f'data:image/jpeg;base64,{frame_base64}',
            'players': {
                'home': home_players,
                'away': away_players
            },
            'ball': ball_data,
            'heatmap': {
                'home': home_heatmap_b64,
                'away': away_heatmap_b64,
                'top_players': top_players,
                'home_activity': self.heatmap.get_team_activity('home'),
                'away_activity': self.heatmap.get_team_activity('away')
            },
                'matchup': {
                'ball_player': ball_player_stats,
                'defender': defender_stats,
                'mismatch': mismatch_detected
            },
            'stats': {
                'fps': round(self.fps, 1),
                'time': self.get_game_time(),
                'cameraCount': 1,
                'possession': {
                    'team': 'Home' if possession == 'Westy' else 'Away' if possession == 'Opponent' else 'Unknown',
                    'percent': possession_percent,
                    'home': possession_percent,
                    'away': 100 - possession_percent
                },
                'performance': self._get_performance_data(),
                'enhanced_events': {
                'summary': event_summary,
                'recent': event_types,
                'counts': event_counts
            },
                'shot_quality_3d': {
                    'summary': self.shot_quality_3d.get_shot_quality_summary(),
                    'recent': self.shot_quality_3d.get_recent_shots(5)
                },
                'shotQuality': {
                    'effective': f"{np.random.randint(8, 18)}/{np.random.randint(15, 25)} ({np.random.randint(45, 65)}%)",
                    'contested': f"{np.random.randint(2, 8)}/{np.random.randint(8, 15)}",
                    'open': f"{np.random.randint(6, 12)}/{np.random.randint(8, 14)}",
                    'avg': round(np.random.uniform(45, 75), 1)
                },
                'events': {
                    'shots': np.random.randint(5, 20),
                    'pnr': pnr_count,
                    'fastBreak': np.random.randint(0, 5),
                    'assists': np.random.randint(0, 8)
                }
            },
            'tactic': {
                'name': 'Horns' if len(home_players) >= 3 else 'Analyzing...',
                'description': '2 bigs at elbows' if len(home_players) >= 3 else 'Waiting for players...',
                'detail': 'Drive middle, kick to corner' if len(home_players) >= 3 else 'System analyzing'
            },
            'tactics': tactic_list,
            'status': 'Live'
        }

    def _get_performance_data(self):
        print(f"[Performance] Getting stats...")
        home_stats = self.performance.get_team_stats('home')
        away_stats = self.performance.get_team_stats('away')
        all_stats = self.performance.get_all_stats()
        
        top_players = all_stats.get('top_players', [])
        fatigue_alert = '✅ All players good'
        fatigue_level = 'low'
        
        if top_players:
            for p in top_players[:3]:
                if p.get('fatigue', 0) > 70:
                    fatigue_alert = f"⚠️ Player {p['id']} fatigue: {p['fatigue']:.0f}%"
                    fatigue_level = 'high'
                    break
                elif p.get('fatigue', 0) > 40:
                    fatigue_alert = f"⚠️ Player {p['id']} fatigue: {p['fatigue']:.0f}%"
                    fatigue_level = 'medium'
        
        # Calculate average speed (total distance / total time)
        total_time = self.performance.frame_count / 30 if self.performance.frame_count > 0 else 1
        avg_speed = home_stats.get('total_distance', 0) / total_time if home_stats else 0
        
        return {
            'avgSpeed': round(avg_speed, 1),
            'totalDist': home_stats.get('total_distance', 0) if home_stats else 0,
            'sprints': home_stats.get('sprints', 0) if home_stats else 0,
            'runTime': self.get_game_time(),
            'fatigueAlert': fatigue_alert,
            'fatigueLevel': fatigue_level,
            'homeDistance': home_stats.get('total_distance', 0) if home_stats else 0,
            'awayDistance': away_stats.get('total_distance', 0) if away_stats else 0,
            'homeSprints': home_stats.get('sprints', 0) if home_stats else 0,
            'awaySprints': away_stats.get('sprints', 0) if away_stats else 0
        }
        

    def get_game_time(self):
        elapsed = time.time() - self.start_time
        mins = int(elapsed // 60)
        secs = int(elapsed % 60)
        return f"{mins:02d}:{secs:02d}"
    
    def stop(self):
        self.running = False
        self.wait()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Voop Basketball Analytics")
        self.setMinimumSize(1500, 1000)
        self.resize(1500, 1000)  # Set initial window size
        self.video_file_path = None
        self.loop_video = False
        self.camera_window = None
        
        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Left panel (controls) - Scrollable
        from PyQt6.QtWidgets import QScrollArea

        left_container = QWidget()
        left_container.setStyleSheet("background-color: #0b0f1a;")
        left_container.setMinimumWidth(290)  # Use minimum width, not fixed
        left_container.setMaximumWidth(330)  # Prevent it from getting too wide
        left_layout = QVBoxLayout(left_container)
        left_layout.setSpacing(6)

        # Wrap in a scroll area
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # NO horizontal scroll
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        left_scroll.setStyleSheet("""
            QScrollArea { 
                background-color: #0b0f1a;
                border: none; 
            }
            QScrollBar:vertical {
                background: #1a1a2e;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #2a3344;
                border-radius: 4px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: #f97316;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
                background: transparent;
            }
        """)
        left_scroll.setWidget(left_container)
        
        title = QLabel("🏀 VOOP")
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: #e94560;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        left_layout.addWidget(title)
        
        # Video source
        cam_group = QGroupBox("Video Source")
        cam_layout = QVBoxLayout(cam_group)
        
        self.start_btn = QPushButton("START LIVE CAMERA")
        self.start_btn.setStyleSheet("background-color: #2ecc71; color: white; font-size: 12px; padding: 8px; border-radius: 6px;")
        self.start_btn.clicked.connect(lambda: self.start_camera())
        cam_layout.addWidget(self.start_btn)
        
        self.video_btn = QPushButton("SELECT VIDEO FILE")
        self.video_btn.setStyleSheet("background-color: #3498db; color: white; font-size: 13px; padding: 10px; border-radius: 6px;")
        self.video_btn.clicked.connect(self.select_video_file)
        cam_layout.addWidget(self.video_btn)
        
        self.stop_btn = QPushButton("STOP")
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet("background-color: #e74c3c; color: white; font-size: 13px; padding: 10px; border-radius: 6px;")
        self.stop_btn.clicked.connect(self.stop_camera)
        cam_layout.addWidget(self.stop_btn)
        
        self.loop_checkbox = QCheckBox("Loop Video")
        self.loop_checkbox.setStyleSheet("color: white; padding: 5px;")
        self.loop_checkbox.setEnabled(False)
        cam_layout.addWidget(self.loop_checkbox)
        
        # NEW: Open Camera View button
        self.cam_view_btn = QPushButton("📷 OPEN CAMERA VIEW")
        self.cam_view_btn.setStyleSheet("background-color: #8b5cf6; color: white; font-size: 13px; padding: 10px; border-radius: 6px;")
        self.cam_view_btn.clicked.connect(self.open_camera_view)
        self.cam_view_btn.setEnabled(False)
        cam_layout.addWidget(self.cam_view_btn)

        # Calibrate Court button
        self.calibrate_btn = QPushButton("🎯 CALIBRATE COURT (4 corners)")
        self.calibrate_btn.setStyleSheet("background-color: #8b5cf6; color: white; font-size: 13px; padding: 10px; border-radius: 6px;")
        self.calibrate_btn.clicked.connect(self.calibrate_court)
        self.calibrate_btn.setEnabled(False)
        cam_layout.addWidget(self.calibrate_btn)

        # Report button
        self.report_btn = QPushButton("Cmd + R to Get Report")
        self.report_btn.setStyleSheet("background-color: #9b59b6; color: white; font-size: 13px; padding: 10px; border-radius: 6px;")
        self.report_btn.clicked.connect(self.generate_report)
        self.report_btn.setEnabled(False)
        cam_layout.addWidget(self.report_btn)
        
        left_layout.addWidget(cam_group)
        
        # Learning
        learn_group = QGroupBox("Team Color Learning")
        learn_layout = QVBoxLayout(learn_group)
        
        self.home_btn = QPushButton("LEARN HOME TEAM")
        self.home_btn.setEnabled(False)
        self.home_btn.setStyleSheet("background-color: #f39c12; padding: 8px; font-size: 12px;")
        self.home_btn.clicked.connect(lambda: self.start_learning('home'))
        learn_layout.addWidget(self.home_btn)
        
        self.home_status = QLabel("⚡ Not learned (0/5)")
        self.home_status.setStyleSheet("color: #f39c12; padding: 3px;")
        learn_layout.addWidget(self.home_status)
        
        self.away_btn = QPushButton("LEARN AWAY TEAM")
        self.away_btn.setEnabled(False)
        self.away_btn.setStyleSheet("background-color: #e74c3c; padding: 8px; font-size: 12px;")
        self.away_btn.clicked.connect(lambda: self.start_learning('away'))
        learn_layout.addWidget(self.away_btn)
        
        self.away_status = QLabel("⚡ Not learned (0/5)")
        self.away_status.setStyleSheet("color: #e74c3c; padding: 3px;")
        learn_layout.addWidget(self.away_status)
        
        left_layout.addWidget(learn_group)
        
        # === BALL TRACKING BUTTON (NEW) ===
        ball_group = QGroupBox("Ball Tracking")
        ball_layout = QVBoxLayout(ball_group)
        
        self.ball_btn = QPushButton("🎯 LEARN BALL (click on ball)")
        self.ball_btn.setEnabled(False)
        self.ball_btn.setStyleSheet("background-color: #22c55e; color: white; padding: 8px; font-size: 12px; border-radius: 6px;")
        self.ball_btn.clicked.connect(lambda: self._ball_learning_action())
        ball_layout.addWidget(self.ball_btn)
        
        self.ball_status = QLabel("⚡ Ball not set")
        self.ball_status.setStyleSheet("color: #22c55e; padding: 3px;")
        ball_layout.addWidget(self.ball_status)
        
        left_layout.addWidget(ball_group)

        # Team names
        name_group = QGroupBox("Team Names")
        name_layout = QFormLayout(name_group)
        
        self.home_name = QLineEdit("Home")
        self.home_name.setStyleSheet("padding: 4px;")
        name_layout.addRow("Home:", self.home_name)
        
        self.away_name = QLineEdit("Away")
        self.away_name.setStyleSheet("padding: 4px;")
        name_layout.addRow("Away:", self.away_name)
        
        left_layout.addWidget(name_group)
        
        guide = QLabel(
            "HOW TO USE:\n"
            "1. Start camera or load video\n"
            "2. Click 'OPEN CAMERA VIEW'\n"
            "3. Click LEARN HOME TEAM\n"
            "4. Click on 5 Home players in camera view\n"
            "5. Click LEARN AWAY TEAM\n"
            "🟡 Home  🔴 Away"
        )
        guide.setWordWrap(True)
        guide.setStyleSheet("background-color: #1f2937; padding: 10px; border-radius: 8px; font-size: 12px;")
        left_layout.addWidget(guide)
        
        left_layout.addStretch()
        
        # Right panel - HTML Dashboard
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        
        self.web_view = QWebEngineView()
        self.web_view.setMinimumHeight(400)
        
        html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dashboard.html')
        if os.path.exists(html_path):
            self.web_view.load(QUrl.fromLocalFile(html_path))
        else:
            self.web_view.setHtml("<html><body><h1>dashboard.html not found</h1></body></html>")
        
        # === SETUP CAMERA DATA BRIDGE ===
        def setup_bridge():
            js_code = """
                // Store camera data
                window._cameraData = null;
                
                window.pyqtBridge = {
                    onCameraMove: function(data) {
                        window._cameraData = data;
                        console.log('Camera data saved:', data);
                    }
                };
                
                // Function for Python to read camera data
                window.getCameraData = function() {
                    return window._cameraData;
                };
                
                console.log('Bridge ready');
            """
            self.web_view.page().runJavaScript(js_code)

        self.web_view.loadFinished.connect(setup_bridge)
    
        
        
        right_layout.addWidget(self.web_view)
        
        self.poll_timer = QTimer()
        self.poll_timer.timeout.connect(self.poll_camera_data)
        self.poll_timer.start(3000)

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready - Start camera or load video")
        
        layout.addWidget(left_scroll)
        layout.addWidget(right, stretch=2)
        
        self.setStyleSheet("""
            QMainWindow { background-color: #0b0f1a; }
            QGroupBox { 
                color: white; 
                border: 2px solid #2a3344; 
                border-radius: 8px; 
                margin-top: 20px;
                padding-top: 10px;
            }
            QGroupBox::title { 
                color: #f97316;
                background-color: #0b0f1a;
                padding: 0 8px;
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 10px;
            }
            QLabel { color: white; }
            QLineEdit { background-color: #1a1a2e; color: white; border: 1px solid #2a3344; border-radius: 4px; padding: 4px; }
            QCheckBox { color: white; }
            QPushButton { font-weight: bold; }
            QScrollArea { background-color: #0b0f1a; border: none; }
        """)
        
        self.processor = None
        self.camera_manager = None
        self.camera_positions = {}
        self.camera_assignments = {}
        self.learning_ball = False
    
    def select_video_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Video File", 
            os.path.expanduser("~"), 
            "Video Files (*.mp4 *.mov *.avi *.mkv)"
        )
        if file_path:
            self.video_file_path = file_path
            self.loop_video = self.loop_checkbox.isChecked()
            self.start_camera(video_path=file_path)
    
    def open_camera_view(self):
        """Open the separate Camera Window for raw feed + learning"""
        if not self.processor:
            return
        
        # If window already exists, just bring it to front
        if self.camera_window is not None:
            self.camera_window.raise_()
            self.camera_window.activateWindow()
            return
        
        self.camera_window = CameraWindow(self.processor)
        self.processor.camera_frame.connect(self.camera_window.update_frame)
        self.processor.camera_status.connect(self.camera_window.set_status)
        
        # Connect close event to reset button
        self.camera_window.destroyed.connect(self.on_camera_window_closed)
        
        self.cam_view_btn.setEnabled(False)
        self.cam_view_btn.setText("📷 CAMERA VIEW OPEN")

    def on_camera_window_closed(self):
        """Called when camera window is closed"""
        self.cam_view_btn.setEnabled(True)
        self.cam_view_btn.setText("📷 OPEN CAMERA VIEW")
        self.camera_window = None

    def calibrate_court(self):
        """Open calibration window to click 4 court corners"""

        if self.camera_positions:
            print("[Calibration] Using camera positions:")
            for cam_id, pos in self.camera_positions.items():
                print(f"  CAM {cam_id}: ({pos['x']:.1f}%, {pos['y']:.1f}%)")
        
        if not self.processor or not self.processor.engine:
            QMessageBox.warning(self, "Warning", "Start camera first!")
            return
        
        if not self.processor or not self.processor.engine:
            QMessageBox.warning(self, "Warning", "Start camera first!")
            return
        
        self.status_bar.showMessage("Calibrating court - Click 4 corners (TL, TR, BR, BL)")
        
        # This opens an OpenCV window where you click 4 corners
        success = self.processor.engine.court_calibrator.calibrate()
        
        if success:
            self.status_bar.showMessage("✅ Court calibrated!", 3000)
            QMessageBox.information(self, "Calibration Complete", 
                "Court calibrated successfully!\n\n"
                "The system now knows where the court is.\n"
                "Players outside the court will be ignored.")
        else:
            self.status_bar.showMessage("❌ Calibration cancelled or failed", 2000)
    
    def start_camera(self, video_path=None):
        """
        Start camera with multi-camera support.
        Detects available cameras and starts them all.
        """
        if self.processor and hasattr(self.processor, 'performance'):
            self.processor.performance = PerformanceTracker(fps=30)

        # Stop any existing processor
        if self.processor:
            self.processor.stop()
            self.processor = None
        
        # Stop any existing camera manager
        if self.camera_manager:
            self.camera_manager.stop_all_cameras()
            self.camera_manager = None
        
        # If a video file was selected, use the single-camera mode (existing behavior)
        if video_path:
            config = AppConfig()
            loop = self.loop_checkbox.isChecked() if hasattr(self, 'loop_checkbox') else False
            
            self.processor = VideoProcessor(config, video_path=video_path, loop_video=loop)
            self.processor.parent = self
            self.processor.frame_ready.connect(self.update_dashboard)
            self.processor.status_update.connect(self.status_bar.showMessage)
            self.processor.error_occurred.connect(self.handle_error)
            self.processor.learning_update.connect(self.on_learning_update)
            self.processor.learning_complete.connect(self.on_learning_complete)
            self.processor.start()
            
            self.start_btn.setEnabled(False)
            self.video_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.home_btn.setEnabled(True)
            self.away_btn.setEnabled(True)
            self.loop_checkbox.setEnabled(True)
            self.cam_view_btn.setEnabled(True)
            self.calibrate_btn.setEnabled(True)
            self.ball_btn.setEnabled(True)
            print(f"[Debug] Ball button enabled: {self.ball_btn.isEnabled()}")
            self.cam_view_btn.setText("📷 OPEN CAMERA VIEW")
            print(f"[Debug] Report button enabled: {self.report_btn.isEnabled()}")
            return
        
        # --- MULTI-CAMERA MODE (for live camera) ---
        
        config = AppConfig()
        self.camera_manager = CameraManager(config)
        
        if self.camera_assignments:
            print("[Camera] Using stored assignments:")
            for cam_id, assigned in self.camera_assignments.items():
                if assigned:
                    print(f"  CAM {cam_id} -> USB Camera {assigned}")

        from triangulation import Triangulator
        self.camera_manager.triangulator = Triangulator()
        print("[Triangulation] Initialized")

        if hasattr(self, 'shot_quality_3d'):
            self.shot_quality_3d.set_triangulator(self.camera_manager.triangulator)
            print("[ShotQuality3D] Triangulator set")
        
        self.camera_manager.test_triangulation()

        # Pass the triangulator from camera_manager to shot_quality_3d
        if hasattr(self, 'shot_quality_3d') and self.shot_quality_3d is not None:
            self.shot_quality_3d.set_triangulator(self.camera_manager.triangulator)
            print("[ShotQuality3D] Triangulator connected from CameraManager")

        # Detect available cameras (up to 6)
        available = self.camera_manager.detect_cameras(max_cameras=6)
        
        if not available:
            QMessageBox.warning(self, "Warning", "No cameras detected! Please connect a camera.")
            self.start_btn.setEnabled(True)
            return
        
        # Show which cameras were detected
        cam_list = ", ".join([str(c) for c in available])
        self.status_bar.showMessage(f"Detected {len(available)} cameras: [{cam_list}]")
        
        # Let user select which cameras to use
        # For now, use all detected cameras (up to 6)
        cameras_to_use = available[:6]  # Max 6 cameras
        
        # Start all selected cameras
        self.camera_manager.start_all_cameras(cameras_to_use)
        
        # Set the first camera as primary (sends data to dashboard)
        self.camera_manager.set_primary_camera(cameras_to_use[0])
        
        # For now, we still need the VideoProcessor for the primary camera
        # to handle detection and analytics
        # This is a simplified approach - we'll refine in the next step
        config_primary = AppConfig()
        self.processor = VideoProcessor(config_primary, video_path=None, loop_video=False)
        self.processor.parent = self
        self.processor.frame_ready.connect(self.update_dashboard)
        self.processor.status_update.connect(self.status_bar.showMessage)
        self.processor.error_occurred.connect(self.handle_error)
        self.processor.learning_update.connect(self.on_learning_update)
        self.processor.learning_complete.connect(self.on_learning_complete)
        
        # Start the processor (it will use the primary camera)
        # We need to modify VideoProcessor to accept a camera_manager
        # For now, this will use camera 0
        self.processor.start()
        
        # Update UI
        self.start_btn.setEnabled(False)
        self.video_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.home_btn.setEnabled(True)
        self.away_btn.setEnabled(True)
        self.loop_checkbox.setEnabled(True)
        self.cam_view_btn.setEnabled(True)
        self.calibrate_btn.setEnabled(True)
        self.ball_btn.setEnabled(True)
        
        self.status_bar.showMessage(f"✅ Running {len(cameras_to_use)} cameras. Primary: Camera {cameras_to_use[0]}")


    def stop_camera(self):

        if self.processor and hasattr(self.processor, 'performance'):
            self.processor.performance = PerformanceTracker(fps=30)

        # Stop the processor
        if self.processor:
            self.processor.stop()
            self.processor = None
        
        # Stop the camera manager (multi-camera)
        if self.camera_manager:
            self.camera_manager.stop_all_cameras()
            self.camera_manager = None
            
        self.camera_positions = {}      # ADD THIS
        self.camera_assignments = {}
        
        # Close camera window
        if self.camera_window:
            self.camera_window.close()
            self.camera_window = None
        
        # Reset UI
        self.start_btn.setEnabled(True)
        self.video_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.home_btn.setEnabled(False)
        self.away_btn.setEnabled(False)
        self.loop_checkbox.setEnabled(False)
        self.cam_view_btn.setEnabled(True)
        self.calibrate_btn.setEnabled(False)
        self.ball_btn.setEnabled(False)   # <-- ADD THIS
        self.ball_btn.setText("🎯 LEARN BALL (click on ball)")
        self.ball_status.setText("⚡ Ball not set")
        self.learning_ball = False
        self.cam_view_btn.setText("📷 OPEN CAMERA VIEW")
        self.home_status.setText("⚡ Not learned (0/5)")
        self.away_status.setText("⚡ Not learned (0/5)")
        self.status_bar.showMessage("Stopped")
    
    def update_dashboard(self, data):
        json_data = json.dumps(data)
        js_code = f"window.updateDashboard({json_data});"
        self.web_view.page().runJavaScript(js_code)
    
    def start_learning(self, team):
        if self.processor:
            self.processor.start_learning(team)

    def _ball_learning_action(self):
        """Toggle ball learning mode when button is clicked"""
        print("[Ball] Button clicked!")
        if not self.processor:
            QMessageBox.warning(self, "Warning", "Start camera first!")
            return
        
        if not self.learning_ball:
            # Start learning mode
            self.learning_ball = True
            self.ball_btn.setText("🎯 Click on ball in camera view")
            self.ball_btn.setStyleSheet("background-color: #eab308; color: white; padding: 8px; font-size: 12px; border-radius: 6px;")
            self.status_bar.showMessage("Click on the ball in the camera window", 3000)
            print("[Ball] Learning mode activated")
        else:
            # Cancel learning mode
            self.learning_ball = False
            self.ball_btn.setText("🎯 LEARN BALL (click on ball)")
            self.ball_btn.setStyleSheet("background-color: #22c55e; color: white; padding: 8px; font-size: 12px; border-radius: 6px;")
            self.status_bar.showMessage("Ball learning cancelled", 2000)
            print("[Ball] Learning mode cancelled")

    def start_ball_learning(self):
        """Start ball learning mode"""
        print("[Ball] Start ball learning clicked!")  # Debug
        if not self.processor:
            QMessageBox.warning(self, "Warning", "Start camera first!")
            return
        self.learning_ball = True
        self.ball_btn.setText("🎯 Click on ball in camera view")
        self.ball_btn.setStyleSheet("background-color: #eab308; color: white; padding: 8px; font-size: 12px; border-radius: 6px;")
        self.status_bar.showMessage("Click on the ball in the camera window", 3000)

    def set_ball_position(self, x, y):
        """Set ball position from click - stores color for tracking"""
        if not self.processor:
            return
        
        # Get the frame
        frame = self.processor.engine.current_frame
        if frame is None:
            return
        
        # Clamp click position to frame bounds
        x = max(0, min(x, frame.shape[1] - 1))
        y = max(0, min(y, frame.shape[0] - 1))
        
        # Sample color from 20x20 area around click
        x1 = max(0, x - 10)
        x2 = min(frame.shape[1], x + 10)
        y1 = max(0, y - 10)
        y2 = min(frame.shape[0], y + 10)
        
        ball_roi = frame[y1:y2, x1:x2]
        if ball_roi.size == 0:
            return
        
        # Convert to HSV and get mean/std for tracking
        hsv_roi = cv2.cvtColor(ball_roi, cv2.COLOR_BGR2HSV)
        hsv_mean = np.mean(hsv_roi, axis=(0, 1))
        hsv_std = np.std(hsv_roi, axis=(0, 1))
        
        # Store in engine
        self.processor.engine.ball_color_mean = hsv_mean
        self.processor.engine.ball_color_std = hsv_std
        self.processor.engine.ball_position = (x, y)
        self.processor.engine.ball_tracking_active = True
        
        self.learning_ball = False
        self.ball_btn.setText("✅ Ball Learned!")
        self.ball_btn.setStyleSheet("background-color: #22c55e; color: white; padding: 8px; font-size: 12px; border-radius: 6px;")
        self.ball_status.setText("✅ Tracking active!")
        self.status_bar.showMessage(f"🏀 Ball tracking started!", 3000)
        print(f"[Ball] Tracking started with color: {hsv_mean}")
    
    def on_learning_update(self, team, count):
        if team == 'home':
            self.home_status.setText(f"📸 Learning: {count}/5")
        else:
            self.away_status.setText(f"📸 Learning: {count}/5")
    
    def on_learning_complete(self, team):
        if team == 'home':
            self.home_status.setText("✅ HOME TEAM LEARNED!")
            self.status_bar.showMessage("Home learned! Now learn Away team")
        else:
            self.away_status.setText("✅ AWAY TEAM LEARNED!")
            self.status_bar.showMessage("Both teams learned! System is tracking")
    
    def handle_error(self, msg):
        QMessageBox.critical(self, "Error", msg)
        self.stop_camera()
    
    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_H:
            if self.processor and self.processor.engine:
                self.processor.engine.possession.flip_attack_direction()
                self.status_bar.showMessage("Attack direction flipped", 2000)
        elif event.key() == Qt.Key.Key_R and event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            # Ctrl+R generates the HTML report
            self.generate_report()
        elif event.key() == Qt.Key.Key_R:
            if self.processor and self.processor.engine:
                filename = self.processor.engine.scout.generate_timeout_report()
                self.status_bar.showMessage(f"Report saved: {filename}", 3000)
                QMessageBox.information(self, "Report Generated", f"Timeout report saved as:\n{filename}")
        elif event.key() == Qt.Key.Key_Q:
            self.stop_camera()
            self.close()
        super().keyPressEvent(event)
    
    def closeEvent(self, event):
        """Handle window close event"""
        try:
            if hasattr(self, 'processor'):
                self.processor.camera_frame.disconnect()
                self.processor.camera_status.disconnect()
        except:
            pass
        event.accept()


    def on_camera_moved(self, data):
        """Receive camera positions and assignments from HTML"""
        print("[Python] Camera data received")
        
        if 'positions' in data:
            for cam_id, pos in data['positions'].items():
                print(f"  CAM {cam_id}: ({pos['x']:.1f}%, {pos['y']:.1f}%)")
            self.camera_positions = data['positions']
        
        if 'assignments' in data:
            for cam_id, assigned in data['assignments'].items():
                if assigned:
                    print(f"  CAM {cam_id} -> USB Camera {assigned}")
            self.camera_assignments = data['assignments']
        
        assigned_count = len([a for a in data.get('assignments', {}).values() if a])
        self.status_bar.showMessage(f"📷 {assigned_count} cameras assigned, {len(data.get('positions', {}))} positions saved", 2000)

    def generate_report(self):
        print("[Report] BUTTON WAS CLICKED!!!")  # <-- ADD THIS FIRST LINE
        """Generate an HTML report from current game data"""
        print("[Report] Generate report button clicked")
        if not self.processor or not self.processor.engine:
            QMessageBox.warning(self, "Warning", "No game data available. Start camera first!")
            return
        
        try:
            # Collect game data
            game_data = {
                'home_team': self.home_name.text() or "Home",
                'away_team': self.away_name.text() or "Away",
                'home_score': 0,
                'away_score': 0,
                'duration': self.processor.get_game_time() if hasattr(self.processor, 'get_game_time') else "00:00",
                'possession': {
                    'home': 50,
                    'away': 50
                }
            }
            
            # Get performance data
            performance_data = self.processor.performance.get_all_stats() if hasattr(self.processor, 'performance') else {}
            
            # Generate report
            from report_generator import ReportGenerator
            report_gen = ReportGenerator()
            filepath = report_gen.generate_report(
                game_data, 
                performance_data, 
                [],  # events (empty for now)
                []   # tactics (empty for now)
            )
            
            self.status_bar.showMessage(f"✅ Report saved: {filepath}", 5000)
            QMessageBox.information(self, "Report Generated", 
                f"Game report saved!\n\n"
                f"Location: {filepath}\n\n"
                f"Open in your browser to view.")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to generate report: {str(e)}")

    def poll_camera_data(self):
        """Poll JavaScript for camera data"""
        js_code = """
            (function() {
                var data = window.getCameraData();
                if (data) {
                    return JSON.stringify(data);
                }
                return null;
            })();
        """
        self.web_view.page().runJavaScript(js_code, self.process_polled_data)

    def process_polled_data(self, data_str):
        """Process data from JavaScript poll"""
        if data_str and data_str != 'null':
            try:
                import json
                data = json.loads(data_str)
                self.on_camera_moved(data)
            except Exception as e:
                print(f"[Poll error] {e}")

    def get_camera_positions(self):
        """Return camera positions for calibration"""
        return self.camera_positions
    
    def get_camera_assignments(self):
        """Return camera assignments for calibration"""
        return self.camera_assignments

    def get_mapped_cameras(self):
        """Return list of actual camera IDs based on assignments"""
        mapped = []
        for cam_id, assigned in self.camera_assignments.items():
            if assigned and assigned.isdigit():
                mapped.append(int(assigned))
        return mapped

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())