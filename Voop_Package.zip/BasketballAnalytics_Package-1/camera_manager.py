import cv2
import numpy as np
from PyQt6.QtCore import QThread, pyqtSignal, QMutex, QWaitCondition
from varsity_logic import AppConfig, VarsityAIEngine, normalize_lighting
import time
from triangulation import Triangulator

class CameraWorker(QThread):
    frame_ready = pyqtSignal(object, int)  # (frame, camera_id)
    status_update = pyqtSignal(str, int)   # (message, camera_id)
    error_occurred = pyqtSignal(str, int)  # (error, camera_id)
    
    def __init__(self, camera_id, config):
        super().__init__()
        self.camera_id = camera_id
        self.config = config
        self.running = True
        self.cap = None
        self.engine = VarsityAIEngine(config)
        self.frame_count = 0
        self.fps = 0
        self.last_frame = None
        
    def setup(self):
        try:
            if not self.engine._init_model():
                self.error_occurred.emit("Failed to load YOLO model", self.camera_id)
                return False
            
            self.cap = cv2.VideoCapture(self.camera_id)
            if not self.cap.isOpened():
                self.error_occurred.emit(f"Cannot open camera {self.camera_id}", self.camera_id)
                return False
            
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.frame_width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.frame_height)
            
            if self.engine.court_calibrator.court_polygon is None:
                self.engine.court_calibrator.court_polygon = np.array([
                    [0, 0],
                    [self.config.frame_width, 0],
                    [self.config.frame_width, self.config.frame_height],
                    [0, self.config.frame_height]
                ], dtype=np.int32)
            
            return True
        except Exception as e:
            self.error_occurred.emit(str(e), self.camera_id)
            return False
    
    def run(self):
        if not self.setup():
            return
        
        self.status_update.emit(f"Camera {self.camera_id} ready", self.camera_id)
        
        for _ in range(10):
            self.cap.read()
        
        while self.running and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            
            frame = cv2.resize(frame, (self.config.frame_width, self.config.frame_height))
            frame = normalize_lighting(frame)
            self.last_frame = frame.copy()
            self.frame_ready.emit(frame, self.camera_id)
            
            self.frame_count += 1
            time.sleep(0.03)
        
        if self.cap:
            self.cap.release()
    
    def stop(self):
        self.running = False
        self.wait()


class CameraManager:
    """Manages multiple camera workers"""
    
    def __init__(self, config):
        self.config = config
        self.workers = {}
        self.active_cameras = []
        self.primary_camera_id = None
        self.triangulator = Triangulator()  # ADD THIS
        self.court_dimensions = (28, 15)

    def detect_cameras(self, max_cameras=6):
        """Detect available cameras (0 to max_cameras-1)"""
        available = []
        for i in range(max_cameras):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                available.append(i)
                cap.release()
        return available
    
    def start_camera(self, camera_id):
        """Start a single camera"""
        if camera_id in self.workers:
            return
        
        worker = CameraWorker(camera_id, self.config)
        worker.frame_ready.connect(self.on_frame_ready)
        worker.status_update.connect(self.on_status_update)
        worker.error_occurred.connect(self.on_error)
        worker.start()
        self.workers[camera_id] = worker
        
        if camera_id not in self.active_cameras:
            self.active_cameras.append(camera_id)
    
    def start_all_cameras(self, camera_ids):
        """Start multiple cameras"""
        for cam_id in camera_ids:
            self.start_camera(cam_id)
        
        # Set first camera as primary
        if camera_ids and self.primary_camera_id is None:
            self.primary_camera_id = camera_ids[0]
    
    def stop_camera(self, camera_id):
        """Stop a single camera"""
        if camera_id in self.workers:
            self.workers[camera_id].stop()
            del self.workers[camera_id]
            if camera_id in self.active_cameras:
                self.active_cameras.remove(camera_id)
    
    def stop_all_cameras(self):
        """Stop all cameras"""
        for cam_id in list(self.workers.keys()):
            self.stop_camera(cam_id)
        self.active_cameras = []
        self.primary_camera_id = None
    
    def set_primary_camera(self, camera_id):
        """Set which camera sends data to the dashboard"""
        if camera_id in self.workers:
            self.primary_camera_id = camera_id
    
    def get_frame(self, camera_id):
        """Get the latest frame from a camera"""
        if camera_id in self.workers and self.workers[camera_id].last_frame is not None:
            return self.workers[camera_id].last_frame
        return None
    
    def get_primary_frame(self):
        """Get the latest frame from the primary camera"""
        if self.primary_camera_id and self.primary_camera_id in self.workers:
            return self.get_frame(self.primary_camera_id)
        return None
    
    def on_frame_ready(self, frame, camera_id):
        """Handle frame from worker"""
        # You can process frame here (detection, tracking, etc.)
        pass
    
    def on_status_update(self, message, camera_id):
        """Handle status update from worker"""
        print(f"[Camera {camera_id}] {message}")
    
    def on_error(self, error, camera_id):
        """Handle error from worker"""
        print(f"[Camera {camera_id}] ERROR: {error}")

    def process_multi_camera_frame(self):
        """Process frames from all cameras and triangulate player positions"""
        if len(self.active_cameras) < 2:
            return
            
        frames = {}
            
        for cam_id in self.active_cameras:
            frame = self.get_frame(cam_id)
            if frame is not None:
                frames[cam_id] = frame
            
        if len(frames) >= 2:
            cam_ids = list(frames.keys())
            print(f"[MultiCam] Processing {len(frames)} cameras: {cam_ids}")

    def calibrate_court_3d(self):
        """Calibrate court for 3D mapping using clicked points"""
        print("[3D Calibration] Court dimensions:", self.court_dimensions)
        self.court_dimensions = (28, 15)
        print("[3D Calibration] Using default court dimensions: 28m x 15m")

    def test_triangulation(self):
        """Test triangulation with mock data"""
        print("[Test] Testing triangulation...")
        
        import numpy as np
        
        K = np.array([[1000, 0, 320], [0, 1000, 240], [0, 0, 1]], dtype=np.float32)
        dist = np.zeros(5, dtype=np.float32)
        R = np.eye(3, dtype=np.float32)
        
        T0 = np.array([[0], [0], [0]], dtype=np.float32)
        T1 = np.array([[10], [0], [0]], dtype=np.float32)
        
        if self.triangulator is None:
            from triangulation import Triangulator
            self.triangulator = Triangulator()
        
        self.triangulator.add_camera(0, K, dist, R, T0)
        self.triangulator.add_camera(1, K, dist, R, T1)
        self.triangulator.compute_projection_matrix(0)
        self.triangulator.compute_projection_matrix(1)
        
        point_3d = (5, 0, 0)
        print(f"[Test] Mock 3D point: {point_3d}")
        
        return True