import numpy as np
import cv2
from collections import deque
from typing import List, Dict, Tuple, Optional
from scipy.ndimage import gaussian_filter


class HeatmapGenerator:
    """Generates player position heatmaps"""
    
    def __init__(self, court_width=960, court_height=540, history_frames=300):
        self.court_width = court_width
        self.court_height = court_height
        self.history_frames = history_frames
        self.home_positions = []  # Store home positions directly
        self.away_positions = []  # Store away positions directly
        self.player_history = {}
        self.heatmap = np.zeros((court_height, court_width), dtype=np.float32)
        self.heatmap_players = {}
        self.frame_count = 0
    
    def update(self, players: List[Dict], team: str):
        self.frame_count += 1
        for p in players:
            player_id = p.get('id')
            x = p.get('x')
            y = p.get('y')
            if player_id is None or x is None or y is None:
                continue
            
            # Store in separate lists by team
            if team == 'home':
                self.home_positions.append((int(x), int(y)))
            elif team == 'away':
                self.away_positions.append((int(x), int(y)))
            
            # Also store in player_history for individual tracking
            if player_id not in self.player_history:
                self.player_history[player_id] = {
                    'positions': deque(maxlen=self.history_frames),
                    'team': team,
                    'heatmap': np.zeros((self.court_height, self.court_width), dtype=np.float32)
                }
            self.player_history[player_id]['positions'].append((int(x), int(y)))
    
    def generate_heatmap(self, player_id: Optional[int] = None, team: Optional[str] = None) -> np.ndarray:
        if player_id is not None:
            if player_id not in self.player_history:
                return np.zeros((self.court_height, self.court_width), dtype=np.float32)
            return self._compute_heatmap_from_positions(
                [pos for pos in self.player_history[player_id]['positions']],
                self.court_width,
                self.court_height
            )
        
        # Use the separate lists for team heatmaps
        if team == 'home':
            positions = self.home_positions
            print(f"[Heatmap] Generating HOME heatmap with {len(positions)} positions")
        elif team == 'away':
            positions = self.away_positions
            print(f"[Heatmap] Generating AWAY heatmap with {len(positions)} positions")
        else:
            positions = []
        
        if not positions:
            print(f"[Heatmap] No positions for {team}")
            return np.zeros((self.court_height, self.court_width), dtype=np.float32)
        
        return self._compute_heatmap_from_positions(positions, self.court_width, self.court_height)
    
    def _compute_heatmap_from_positions(self, positions: List[Tuple[int, int]], width: int, height: int) -> np.ndarray:
        if not positions:
            return np.zeros((height, width), dtype=np.float32)
        
        # Create binary mask
        mask = np.zeros((height, width), dtype=np.float32)
        for x, y in positions:
            if 0 <= x < width and 0 <= y < height:
                mask[int(y), int(x)] += 1
        
        # Apply Gaussian filter
        from scipy.ndimage import gaussian_filter
        heatmap = gaussian_filter(mask, sigma=15)
        
        max_val = np.max(heatmap)
        if max_val > 0:
            heatmap = heatmap / max_val
        return heatmap
    
    def get_top_players(self, n: int = 5) -> List[Tuple[int, str, float]]:
        scores = []
        for pid, data in self.player_history.items():
            score = len(data['positions'])
            scores.append((pid, data['team'], score))
        scores.sort(key=lambda x: x[2], reverse=True)
        return scores[:n]
    
    def get_team_activity(self, team: str) -> int:
        if team == 'home':
            return len(self.home_positions)
        elif team == 'away':
            return len(self.away_positions)
        return 0
    
    def clear_history(self):
        self.player_history.clear()
        self.home_positions = []
        self.away_positions = []
        self.heatmap = np.zeros((self.court_height, self.court_width), dtype=np.float32)
        self.frame_count = 0