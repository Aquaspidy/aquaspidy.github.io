import cv2
import numpy as np
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
from PyQt6.QtCore import QThread, pyqtSignal, Qt
from PyQt6.QtGui import QImage, QPixmap


class CameraWindow(QWidget):
    def __init__(self, processor):
        super().__init__()
        self.processor = processor
        self.setWindowTitle("📷 Voop - Camera View (Click to learn colors)")
        self.setMinimumSize(960, 600)
        self.setStyleSheet("background-color: #0b0f1a;")
        
        layout = QVBoxLayout()
        
        # Video label
        self.video_label = QLabel()
        self.video_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_label.setStyleSheet("background-color: #0a0e16; border: 2px solid #2a3344; border-radius: 8px;")
        self.video_label.setMinimumHeight(400)
        # Make it clickable
        self.video_label.mousePressEvent = self.on_video_click
        layout.addWidget(self.video_label)
        
        # Status bar
        self.status_label = QLabel("📷 Camera view - Click on players to learn jersey colors")
        self.status_label.setStyleSheet("color: #c8d0dc; padding: 8px; font-size: 13px;")
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        self.show()
    
    def on_video_click(self, event):
        """Handle click on video - learn colors OR learn ball"""
        if not self.processor:
            return
        
        # Get click position
        x = event.position().x()
        y = event.position().y()
        
        pixmap = self.video_label.pixmap()
        if not pixmap:
            return
        
        label_w = self.video_label.width()
        label_h = self.video_label.height()
        
        pix_w = pixmap.width()
        pix_h = pixmap.height()
        offset_x = (label_w - pix_w) // 2
        offset_y = (label_h - pix_h) // 2
        
        click_x = x - offset_x
        click_y = y - offset_y
        
        frame_w = self.processor.config.frame_width
        frame_h = self.processor.config.frame_height
        scale_x = frame_w / pix_w
        scale_y = frame_h / pix_h
        
        fx = int(click_x * scale_x)
        fy = int(click_y * scale_y)
        
        # Check if ball learning mode is active
        if hasattr(self.processor, 'parent') and self.processor.parent:
            if hasattr(self.processor.parent, 'learning_ball') and self.processor.parent.learning_ball:
                # Set ball position
                self.processor.parent.set_ball_position(fx, fy)
                self.status_label.setText(f"🏀 Ball learned at ({fx}, {fy})")
                # Reset the button
                self.processor.parent.learning_ball = False
                self.processor.parent.ball_btn.setText("🎯 LEARN BALL (click on ball)")
                self.processor.parent.ball_btn.setStyleSheet("background-color: #22c55e; color: white; padding: 8px; font-size: 12px; border-radius: 6px;")
                return
        
        # If learning mode is active, use for color learning
        if self.processor.learning_active:
            self.processor.process_click(fx, fy, frame_w, frame_h)
    
    def update_frame(self, frame):
        if frame is None:
            return
        
        display_frame = frame.copy()
        
        # Draw detection boxes with team colors
        if hasattr(self, 'processor') and self.processor and self.processor.engine:
            if hasattr(self.processor.engine, 'tracked_players'):
                for pid, pdata in self.processor.engine.tracked_players.items():
                    if pdata.get('last_box'):
                        x1, y1, x2, y2 = pdata['last_box']
                        
                        # Get team color
                        team = pdata.get('team_locked')
                        if team == 'Westy':
                            color = (0, 255, 255)  # Yellow
                            label = f"Home {pid}"
                        elif team == 'Opponent':
                            color = (0, 0, 255)    # Red
                            label = f"Away {pid}"
                        else:
                            color = (100, 100, 100)  # Gray
                            label = f"Player {pid}"
                        
                        cv2.rectangle(display_frame, (x1, y1), (x2, y2), color, 3)
                        cv2.putText(display_frame, label, (x1, y1-10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        # Convert and display
        rgb = cv2.cvtColor(display_frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        qt_img = QImage(rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_img)
        scaled = pixmap.scaled(
            self.video_label.width() - 20, 
            self.video_label.height() - 20,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.video_label.setPixmap(scaled)
    
    def set_status(self, text):
        self.status_label.setText(text)
    
    def closeEvent(self, event):
        """Handle window close event"""
        event.accept()
