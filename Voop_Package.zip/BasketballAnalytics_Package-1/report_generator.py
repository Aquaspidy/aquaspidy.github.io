"""
Coaching Report Generator for Voop Analytics
Focuses on performance insights, not scores
"""

import os
import json
import datetime
from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import io
import base64


class ReportGenerator:
    """Generates coaching reports from game data"""
    
    def __init__(self, output_dir="reports"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def generate_report(self, game_data, performance_data, events_data, tactic_data):
        """
        Generate a complete coaching report
        
        Args:
            game_data: dict with game info (teams, duration)
            performance_data: dict from PerformanceTracker
            events_data: list of detected events
            tactic_data: list of detected tactics
        
        Returns:
            str: Path to the generated HTML file
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"coaching_report_{timestamp}.html"
        filepath = os.path.join(self.output_dir, filename)
        
        html_content = self._build_html(
            game_data, performance_data, events_data, tactic_data
        )
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return filepath
    
    def _generate_pie_chart(self, data, title, colors=None):
        """Generate a pie chart and return as base64 image"""
        if not data:
            return None
        
        fig, ax = plt.subplots(figsize=(6, 4))
        fig.patch.set_facecolor('#0b0f1a')
        ax.set_facecolor('#0b0f1a')
        
        labels = list(data.keys())
        values = list(data.values())
        
        if colors is None:
            colors = ['#f97316', '#3b82f6', '#a855f7', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6']
        
        wedges, texts, autotexts = ax.pie(
            values, 
            labels=labels, 
            autopct='%1.1f%%',
            colors=colors[:len(labels)],
            textprops={'color': 'white', 'fontsize': 10, 'weight': 'bold'}
        )
        
        ax.set_title(title, color='white', fontsize=14, weight='bold', pad=20)
        
        buf = io.BytesIO()
        plt.savefig(buf, format='png', facecolor='#0b0f1a', bbox_inches='tight')
        buf.seek(0)
        img_base64 = base64.b64encode(buf.read()).decode('utf-8')
        plt.close(fig)
        
        return img_base64
    
    def _assess_performance(self, value, metric_type):
        """Assess if a performance metric is good/bad/average"""
        if metric_type == 'speed':
            if value > 5.5:
                return '🔴 Excellent', 'elite'
            elif value > 4.0:
                return '🟡 Good', 'good'
            elif value > 2.5:
                return '⚪ Average', 'average'
            else:
                return '🟢 Below Average', 'below'
        
        elif metric_type == 'distance':
            if value > 3000:
                return '🔴 High Work Rate', 'elite'
            elif value > 2000:
                return '🟡 Solid', 'good'
            elif value > 1000:
                return '⚪ Moderate', 'average'
            else:
                return '🟢 Low', 'below'
        
        elif metric_type == 'sprints':
            if value > 30:
                return '🔴 High Intensity', 'elite'
            elif value > 15:
                return '🟡 Good', 'good'
            elif value > 5:
                return '⚪ Moderate', 'average'
            else:
                return '🟢 Low', 'below'
        
        elif metric_type == 'fatigue':
            if value < 30:
                return '🟢 Fresh', 'good'
            elif value < 60:
                return '🟡 Moderate', 'average'
            else:
                return '🔴 Tired', 'poor'
        
        return '⚪ Average', 'average'
    
    def _build_html(self, game_data, performance_data, events_data, tactic_data):
        """Build the HTML content"""
        
        # Extract data
        home_team = game_data.get('home_team', 'Home')
        away_team = game_data.get('away_team', 'Away')
        game_duration = game_data.get('duration', '00:00')
        possession_pct = game_data.get('possession', {'home': 50, 'away': 50})
        
        # Performance stats
        home_stats = performance_data.get('home', {})
        away_stats = performance_data.get('away', {})
        top_players = performance_data.get('top_players', [])
        total_players = performance_data.get('total_players', 0)
        
        # Assess performance
        home_speed = home_stats.get('avg_distance', 0) / max(1, total_players)
        away_speed = away_stats.get('avg_distance', 0) / max(1, total_players)
        
        home_speed_rating, home_speed_class = self._assess_performance(home_speed, 'speed')
        away_speed_rating, away_speed_class = self._assess_performance(away_speed, 'speed')
        
        home_dist = home_stats.get('total_distance', 0)
        away_dist = away_stats.get('total_distance', 0)
        home_dist_rating, home_dist_class = self._assess_performance(home_dist, 'distance')
        away_dist_rating, away_dist_class = self._assess_performance(away_dist, 'distance')
        
        home_sprints = home_stats.get('sprints', 0)
        away_sprints = away_stats.get('sprints', 0)
        home_sprint_rating, home_sprint_class = self._assess_performance(home_sprints, 'sprints')
        away_sprint_rating, away_sprint_class = self._assess_performance(away_sprints, 'sprints')
        
        # Fatigue assessment
        home_fatigue = home_stats.get('fatigue', 0) if isinstance(home_stats, dict) else 0
        away_fatigue = away_stats.get('fatigue', 0) if isinstance(away_stats, dict) else 0
        home_fatigue_rating, home_fatigue_class = self._assess_performance(home_fatigue, 'fatigue')
        away_fatigue_rating, away_fatigue_class = self._assess_performance(away_fatigue, 'fatigue')
        
        # Build player rows
        player_rows = ""
        for p in top_players[:10]:
            fatigue_rating, _ = self._assess_performance(p.get('fatigue', 0), 'fatigue')
            player_rows += f"""
                <tr>
                    <td>{p['id']}</td>
                    <td>{p['team'].title()}</td>
                    <td>{p['distance']:.0f}m</td>
                    <td>{p['avg_speed']:.1f} km/h</td>
                    <td>{p['sprints']}</td>
                    <td>{fatigue_rating}</td>
                </tr>
            """
        
        # Build event rows
        event_rows = ""
        pnr_events = []
        mismatch_events = []
        transition_events = []
        
        for e in events_data[:30]:
            event_type = e.get('type', 'Unknown')
            
            # Track PnR events
            if event_type == 'PnR':
                pnr_events.append(e)
                event_rows += f"""
                    <tr>
                        <td>{e.get('time', '--')}</td>
                        <td><span class="event-pnr">🔄 Pick & Roll</span></td>
                        <td>{e.get('detail', '')}</td>
                        <td>{e.get('team', '--')}</td>
                    </tr>
                """
            elif event_type == 'Mismatch':
                mismatch_events.append(e)
                event_rows += f"""
                    <tr>
                        <td>{e.get('time', '--')}</td>
                        <td><span class="event-mismatch">⚠️ Mismatch</span></td>
                        <td>{e.get('detail', '')}</td>
                        <td>{e.get('team', '--')}</td>
                    </tr>
                """
            elif event_type in ['FastBreak', 'Transition']:
                transition_events.append(e)
                event_rows += f"""
                    <tr>
                        <td>{e.get('time', '--')}</td>
                        <td><span class="event-fastbreak">⚡ Fast Break</span></td>
                        <td>{e.get('detail', '')}</td>
                        <td>{e.get('team', '--')}</td>
                    </tr>
                """
            else:
                event_rows += f"""
                    <tr>
                        <td>{e.get('time', '--')}</td>
                        <td>{event_type}</td>
                        <td>{e.get('detail', '')}</td>
                        <td>{e.get('team', '--')}</td>
                    </tr>
                """
        
        # Build tactic rows
        tactic_rows = ""
        tactic_counts = {}
        for t in tactic_data[:10]:
            tactic_name = t.get('name', 'Unknown')
            tactic_counts[tactic_name] = tactic_counts.get(tactic_name, 0) + 1
            tactic_rows += f"""
                <tr>
                    <td>{t.get('time', '--')}</td>
                    <td><strong>{tactic_name}</strong></td>
                    <td>{t.get('description', '')}</td>
                    <td>{t.get('confidence', '--')}%</td>
                    <td>{t.get('team', '--')}</td>
                </tr>
            """
        
        # Generate pie chart for tactics
        pie_img = None
        if tactic_counts:
            pie_img = self._generate_pie_chart(tactic_counts, "Play Type Distribution")
        
        pie_img_tag = f'<img src="data:image/png;base64,{pie_img}" style="max-width:100%;border-radius:12px;">' if pie_img else '<p style="color:#8895aa;">No tactics data available</p>'
        
        # PnR analysis
        pnr_analysis = ""
        if pnr_events:
            successful_pnr = [e for e in pnr_events if e.get('result') == 'success']
            pnr_success_rate = (len(successful_pnr) / len(pnr_events)) * 100 if pnr_events else 0
            pnr_analysis = f"""
            <div class="stat-box" style="grid-column: span 2;">
                <div class="number">{len(pnr_events)}</div>
                <div class="label">Total Pick & Rolls</div>
                <div style="color:{'#22c55e' if pnr_success_rate > 50 else '#f97316'};font-size:14px;margin-top:4px;">
                    {pnr_success_rate:.0f}% Success Rate
                </div>
            </div>
            """
        
        # Mismatch analysis
        mismatch_analysis = ""
        if mismatch_events:
            mismatch_analysis = f"""
            <div class="stat-box" style="grid-column: span 2;">
                <div class="number">{len(mismatch_events)}</div>
                <div class="label">Mismatches Forced</div>
                <div style="color:#f59e0b;font-size:14px;margin-top:4px;">
                    Size advantages created
                </div>
            </div>
            """
        
        # Transition analysis
        transition_analysis = ""
        if transition_events:
            transition_analysis = f"""
            <div class="stat-box" style="grid-column: span 2;">
                <div class="number">{len(transition_events)}</div>
                <div class="label">Fast Break Opportunities</div>
                <div style="color:#f97316;font-size:14px;margin-top:4px;">
                    Transition chances
                </div>
            </div>
            """
        
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🏀 Voop Coaching Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0b0f1a;
            color: #e8edf5;
            padding: 40px;
            max-width: 1200px;
            margin: 0 auto;
        }}
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 2px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }}
        .logo {{
            font-size: 28px;
            font-weight: 700;
        }}
        .logo span {{ color: #f97316; }}
        .timestamp {{ color: #8895aa; font-size: 14px; }}
        
        .section {{
            background: rgba(255,255,255,0.03);
            border-radius: 16px;
            padding: 24px 28px;
            margin-bottom: 24px;
            border: 1px solid rgba(255,255,255,0.06);
        }}
        .section h2 {{
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            color: #f97316;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }}
        
        .insight-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }}
        .insight-card {{
            background: rgba(255,255,255,0.05);
            padding: 16px 20px;
            border-radius: 12px;
            border-left: 4px solid #f97316;
        }}
        .insight-card .label {{ font-size: 13px; color: #8895aa; }}
        .insight-card .value {{ font-size: 24px; font-weight: 700; }}
        .insight-card .rating {{ font-size: 14px; margin-top: 4px; }}
        .rating.elite {{ color: #22c55e; }}
        .rating.good {{ color: #3b82f6; }}
        .rating.average {{ color: #f59e0b; }}
        .rating.below {{ color: #ef4444; }}
        .rating.poor {{ color: #ef4444; }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
        }}
        .stat-box {{
            background: rgba(255,255,255,0.05);
            padding: 16px 20px;
            border-radius: 12px;
            text-align: center;
        }}
        .stat-box .number {{
            font-size: 28px;
            font-weight: 700;
        }}
        .stat-box .number.home {{ color: #f97316; }}
        .stat-box .number.away {{ color: #3b82f6; }}
        .stat-box .label {{ font-size: 13px; color: #8895aa; margin-top: 4px; }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        th {{
            text-align: left;
            padding: 10px 12px;
            color: #8895aa;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }}
        td {{
            padding: 10px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.04);
            font-size: 14px;
        }}
        tr:hover {{ background: rgba(255,255,255,0.03); }}
        
        .event-pnr {{ color: #a855f7; font-weight: 600; }}
        .event-shot {{ color: #22c55e; font-weight: 600; }}
        .event-fastbreak {{ color: #f97316; font-weight: 600; }}
        .event-mismatch {{ color: #f59e0b; font-weight: 600; }}
        .event-drive {{ color: #8b5cf6; font-weight: 600; }}
        .event-pass {{ color: #06b6d4; font-weight: 600; }}
        
        .footer {{
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255,255,255,0.06);
            color: #5f6a7e;
            font-size: 13px;
        }}
        
        @media (max-width: 700px) {{
            .stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
            .insight-grid {{ grid-template-columns: 1fr; }}
            body {{ padding: 20px; }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">🏀 Voop <span>Coaching Report</span></div>
        <div class="timestamp">Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
    </div>
    
    <!-- Game Info -->
    <div class="section">
        <h2>📋 Game Overview</h2>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
            <div>
                <div style="color:#f97316;font-weight:700;font-size:18px;">🏠 {home_team}</div>
                <div style="color:#8895aa;font-size:14px;">Possession: {possession_pct.get('home', 50)}%</div>
            </div>
            <div>
                <div style="color:#3b82f6;font-weight:700;font-size:18px;">✈️ {away_team}</div>
                <div style="color:#8895aa;font-size:14px;">Possession: {possession_pct.get('away', 50)}%</div>
            </div>
            <div style="grid-column:1/-1;color:#8895aa;font-size:14px;">⏱️ Game Duration: {game_duration}</div>
        </div>
    </div>
    
    <!-- Performance Assessment -->
    <div class="section">
        <h2>🏃 Performance Assessment</h2>
        
        <div style="margin-bottom:16px;">
            <div style="color:#f97316;font-weight:600;font-size:16px;">🏠 {home_team}</div>
            <div class="insight-grid">
                <div class="insight-card">
                    <div class="label">⚡ Average Speed</div>
                    <div class="value">{home_speed:.1f} km/h</div>
                    <div class="rating {home_speed_class}">{home_speed_rating}</div>
                </div>
                <div class="insight-card">
                    <div class="label">📏 Total Distance</div>
                    <div class="value">{home_dist:.0f} m</div>
                    <div class="rating {home_dist_class}">{home_dist_rating}</div>
                </div>
                <div class="insight-card">
                    <div class="label">💨 Sprints</div>
                    <div class="value">{home_sprints}</div>
                    <div class="rating {home_sprint_class}">{home_sprint_rating}</div>
                </div>
                <div class="insight-card">
                    <div class="label">🪫 Fatigue</div>
                    <div class="value">{home_fatigue:.0f}%</div>
                    <div class="rating {home_fatigue_class}">{home_fatigue_rating}</div>
                </div>
            </div>
        </div>
        
        <div>
            <div style="color:#3b82f6;font-weight:600;font-size:16px;">✈️ {away_team}</div>
            <div class="insight-grid">
                <div class="insight-card">
                    <div class="label">⚡ Average Speed</div>
                    <div class="value">{away_speed:.1f} km/h</div>
                    <div class="rating {away_speed_class}">{away_speed_rating}</div>
                </div>
                <div class="insight-card">
                    <div class="label">📏 Total Distance</div>
                    <div class="value">{away_dist:.0f} m</div>
                    <div class="rating {away_dist_class}">{away_dist_rating}</div>
                </div>
                <div class="insight-card">
                    <div class="label">💨 Sprints</div>
                    <div class="value">{away_sprints}</div>
                    <div class="rating {away_sprint_class}">{away_sprint_rating}</div>
                </div>
                <div class="insight-card">
                    <div class="label">🪫 Fatigue</div>
                    <div class="value">{away_fatigue:.0f}%</div>
                    <div class="rating {away_fatigue_class}">{away_fatigue_rating}</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Top Players -->
    <div class="section">
        <h2>🏃 Top Players</h2>
        <table>
            <thead>
                <tr>
                    <th>Player</th>
                    <th>Team</th>
                    <th>Distance</th>
                    <th>Avg Speed</th>
                    <th>Sprints</th>
                    <th>Fatigue</th>
                </tr>
            </thead>
            <tbody>
                {player_rows if player_rows else '<tr><td colspan="6" style="text-align:center;color:#8895aa;">No player data available</td></tr>'}
            </tbody>
        </table>
    </div>
    
    <!-- Play Types (Pie Chart) -->
    <div class="section">
        <h2>📊 Play Type Distribution</h2>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
            <div>
                {pie_img_tag}
            </div>
            <div>
                <div style="color:#8895aa;font-size:14px;margin-bottom:12px;">
                    Breakdown of plays run by both teams
                </div>
                <table>
                    <thead>
                        <tr><th>Play Type</th><th>Count</th></tr>
                    </thead>
                    <tbody>
                        {''.join([f'<tr><td>{k}</td><td>{v}</td></tr>' for k, v in tactic_counts.items()]) if tactic_counts else '<tr><td colspan="2" style="text-align:center;color:#8895aa;">No tactics data available</td></tr>'}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Key Events -->
    <div class="section">
        <h2>⚡ Key Events</h2>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:16px;">
            {pnr_analysis}
            {mismatch_analysis}
            {transition_analysis}
        </div>
        <table>
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Event</th>
                    <th>Detail</th>
                    <th>Team</th>
                </tr>
            </thead>
            <tbody>
                {event_rows if event_rows else '<tr><td colspan="4" style="text-align:center;color:#8895aa;">No events detected</td></tr>'}
            </tbody>
        </table>
    </div>
    
    <!-- Tactics -->
    <div class="section">
        <h2>🧠 Tactics Detected</h2>
        <table>
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Tactic</th>
                    <th>Description</th>
                    <th>Confidence</th>
                    <th>Team</th>
                </tr>
            </thead>
            <tbody>
                {tactic_rows if tactic_rows else '<tr><td colspan="5" style="text-align:center;color:#8895aa;">No tactics detected</td></tr>'}
            </tbody>
        </table>
    </div>
    
    <!-- Coaching Summary -->
    <div class="section" style="border-left:4px solid #f97316;">
        <h2>🧠 Coaching Summary</h2>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
            <div>
                <div style="color:#f97316;font-weight:600;font-size:16px;margin-bottom:8px;">🏠 {home_team}</div>
                <ul style="color:#c8d0dc;font-size:14px;list-style:none;padding:0;">
                    <li style="padding:4px 0;">• Speed: {home_speed_rating}</li>
                    <li style="padding:4px 0;">• Work Rate: {home_dist_rating}</li>
                    <li style="padding:4px 0;">• Intensity: {home_sprint_rating}</li>
                    <li style="padding:4px 0;">• Fatigue: {home_fatigue_rating}</li>
                </ul>
            </div>
            <div>
                <div style="color:#3b82f6;font-weight:600;font-size:16px;margin-bottom:8px;">✈️ {away_team}</div>
                <ul style="color:#c8d0dc;font-size:14px;list-style:none;padding:0;">
                    <li style="padding:4px 0;">• Speed: {away_speed_rating}</li>
                    <li style="padding:4px 0;">• Work Rate: {away_dist_rating}</li>
                    <li style="padding:4px 0;">• Intensity: {away_sprint_rating}</li>
                    <li style="padding:4px 0;">• Fatigue: {away_fatigue_rating}</li>
                </ul>
            </div>
        </div>
        <div style="margin-top:16px;padding-top:16px;border-top:1px solid rgba(255,255,255,0.06);color:#8895aa;font-size:14px;">
            💡 Tip: Higher intensity often leads to better results, but watch for fatigue in the 4th quarter.
        </div>
    </div>
    
    <div class="footer">
        Generated by Voop Analytics • Data captured in real-time from game tracking
    </div>
</body>
</html>
"""
        return html