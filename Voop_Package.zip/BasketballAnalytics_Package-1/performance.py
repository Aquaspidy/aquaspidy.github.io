"""
Performance Analytics Module
Calculates player and team performance metrics from tracking data
"""

import numpy as np
from collections import deque
import math


class PerformanceTracker:
    """Tracks performance metrics for all players"""
    
    def __init__(self, fps=30):
        self.fps = fps
        self.dt = 1.0 / fps
        self.frame_count = 0
        
        # Player data storage
        self.player_data = {}  # player_id -> PlayerStats
        
        # Team data
        self.team_data = {
            'home': {'total_distance': 0, 'sprints': 0, 'possession_time': 0},
            'away': {'total_distance': 0, 'sprints': 0, 'possession_time': 0}
        }
        
        # History for charts
        self.history = {
            'home_speed': deque(maxlen=300),
            'away_speed': deque(maxlen=300),
            'home_spread': deque(maxlen=300),
            'away_spread': deque(maxlen=300),
            'home_depth': deque(maxlen=300),
            'away_depth': deque(maxlen=300),
            'possession': deque(maxlen=300)
        }
        
        self.frame_count = 0
        self.game_time = 0
        
    def update_player(self, player_id, x, y, team):
        """Update a player's position and calculate metrics"""
        self.frame_count += 1
        if player_id not in self.player_data:
            self.player_data[player_id] = PlayerStats(player_id, team, self.fps)
        
        stats = self.player_data[player_id]
        
        # Get the distance moved this frame
        distance_moved = stats.update_position(x, y)
        
        # Update team totals (increment by the distance moved this frame)
        if distance_moved is not None and distance_moved > 0.001:
            self.team_data[team]['total_distance'] += distance_moved
    
    def update_possession(self, team):
        """Update possession time"""
        if team in self.team_data:
            self.team_data[team]['possession_time'] += self.dt
    
    def get_player_stats(self, player_id):
        if player_id in self.player_data:
            return self.player_data[player_id].get_stats()
        return None
    
    def get_team_stats(self, team):
        """Get stats for a team"""
        if team in self.team_data:
            data = self.team_data[team]
            
            # Calculate additional metrics
            total_players = len([p for p in self.player_data.values() if p.team == team])
            
            return {
                'total_distance': round(data['total_distance'], 1),
                'avg_distance': round(data['total_distance'] / max(1, total_players), 1),
                'sprints': data['sprints'],
                'possession_time': round(data['possession_time'], 1),
                'possession_pct': self._calculate_possession_pct(team)
            }
        return None
    
    def _calculate_possession_pct(self, team):
        """Calculate possession percentage for a team"""
        total_time = self.team_data['home']['possession_time'] + self.team_data['away']['possession_time']
        if total_time == 0:
            return 50
        return round((self.team_data[team]['possession_time'] / total_time) * 100, 1)
    
    def get_formation_metrics(self, team_players):
        """
        Calculate formation spread and depth
        
        Args:
            team_players: list of (x, y) positions for a team
        
        Returns:
            dict: {spread, depth, centroid_x, centroid_y}
        """
        if len(team_players) < 2:
            return {'spread': 0, 'depth': 0, 'centroid_x': 0, 'centroid_y': 0}
        
        positions = np.array(team_players)
        
        spread = np.std(positions[:, 0])
        depth = np.std(positions[:, 1])
        centroid_x = np.mean(positions[:, 0])
        centroid_y = np.mean(positions[:, 1])
        
        return {
            'spread': round(spread, 2),
            'depth': round(depth, 2),
            'centroid_x': round(centroid_x, 2),
            'centroid_y': round(centroid_y, 2)
        }
    
    def get_all_stats(self):
        """Get all stats for display"""
        home_stats = self.get_team_stats('home')
        away_stats = self.get_team_stats('away')
        
        # Get top players by distance
        all_players = []
        for pid, stats in self.player_data.items():
            stats_dict = stats.get_stats()
            all_players.append({
                'id': pid,
                'team': stats.team,
                'distance': stats_dict['total_distance'],
                'avg_speed': stats_dict['avg_speed'],
                'sprints': stats_dict['sprints'],
                'fatigue': stats_dict['fatigue_index']
            })
        
        # Sort by distance (top 5)
        top_players = sorted(all_players, key=lambda x: x['distance'], reverse=True)[:5]
        
        return {
            'home': home_stats,
            'away': away_stats,
            'top_players': top_players,
            'total_players': len(self.player_data)
        }


class PlayerStats:
    """Individual player statistics"""
    
    def __init__(self, player_id, team, fps=30):
        self.player_id = player_id
        self.team = team
        self.fps = fps
        self.dt = 1.0 / fps
        
        self.positions = deque(maxlen=60)  # Last 60 positions (2 seconds)
        self.distances = deque(maxlen=60)
        self.speeds = deque(maxlen=60)
        
        self.total_distance = 0
        self.sprint_count = 0
        self.high_intensity_runs = 0
        self.max_speed = 0
        
        self.last_position = None
        self.is_sprinting = False
        self.sprint_start_frame = 0
        
        self.fatigue_index = 0
        self.fatigue_frames = 0
        
    def update_position(self, x, y):
        """Update player position and calculate metrics. Returns distance moved."""
        current_pos = (x, y)
        self.positions.append(current_pos)
        
        distance_moved = 0
        
        if self.last_position is not None:
            # Calculate distance
            dx = current_pos[0] - self.last_position[0]
            dy = current_pos[1] - self.last_position[1]
            distance_moved = math.sqrt(dx*dx + dy*dy)
            
            # Only count meaningful movement
            if distance_moved > 0.001:
                self.total_distance += distance_moved
                self.distances.append(distance_moved)
                
                # Calculate speed (m/s)
                speed = distance_moved / self.dt
                self.speeds.append(speed)
                
                # Update max speed
                if speed > self.max_speed:
                    self.max_speed = speed
                
                # Detect sprint (>5.5 m/s)
                if speed > 5.5 and not self.is_sprinting:
                    self.is_sprinting = True
                    self.sprint_start_frame = len(self.positions)
                elif speed < 4.0 and self.is_sprinting:
                    self.is_sprinting = False
                    sprint_duration = len(self.positions) - self.sprint_start_frame
                    if sprint_duration > 5:
                        self.sprint_count += 1
                        self.high_intensity_runs += 1
        
        self.last_position = current_pos
        
        # Update fatigue index (every 30 frames)
        self.fatigue_frames += 1
        if self.fatigue_frames % 30 == 0:
            self._update_fatigue()
        
        return distance_moved
    
    def _update_fatigue(self):
        """Calculate fatigue index based on recent activity"""
        if len(self.speeds) < 10:
            return
        
        # Recent speed (last 30 frames)
        recent_speeds = list(self.speeds)[-30:]
        avg_recent_speed = np.mean(recent_speeds) if recent_speeds else 0
        
        # Peak speed
        max_recent = np.max(recent_speeds) if recent_speeds else 0
        
        # Fatigue factors:
        # 1. High sprint count
        # 2. High total distance
        # 3. Recent speed drop (fatigue = speed dropping)
        # 4. Long game time
        
        sprint_factor = min(1.0, self.sprint_count / 10)
        distance_factor = min(1.0, self.total_distance / 200)  # 200 meters = high
        time_factor = min(1.0, self.fatigue_frames / 1800)  # 60 seconds = high
        
        # Calculate fatigue (0-100)
        fatigue = (sprint_factor * 0.4 + distance_factor * 0.3 + time_factor * 0.3) * 100
        self.fatigue_index = min(100, fatigue)
    
    def get_stats(self):
        """Get all stats for this player"""
        avg_speed = np.mean(self.speeds) if self.speeds else 0
        
        # Calculate speed distribution
        speed_zones = {'walk': 0, 'jog': 0, 'run': 0, 'sprint': 0}
        if self.speeds:
            for s in self.speeds:
                if s < 1.5:
                    speed_zones['walk'] += 1
                elif s < 3.0:
                    speed_zones['jog'] += 1
                elif s < 5.5:
                    speed_zones['run'] += 1
                else:
                    speed_zones['sprint'] += 1
            
            total = sum(speed_zones.values())
            if total > 0:
                for key in speed_zones:
                    speed_zones[key] = round((speed_zones[key] / total) * 100, 1)
        
        # Fatigue level
        if self.fatigue_index > 70:
            fatigue_level = 'high'
        elif self.fatigue_index > 40:
            fatigue_level = 'medium'
        else:
            fatigue_level = 'low'
        
        return {
            'player_id': self.player_id,
            'team': self.team,
            'total_distance': round(self.total_distance, 1),
            'avg_speed': round(avg_speed, 2),
            'max_speed': round(self.max_speed, 2),
            'sprints': self.sprint_count,
            'high_intensity_runs': self.high_intensity_runs,
            'speed_zones': speed_zones,
            'fatigue_index': round(self.fatigue_index, 1),
            'fatigue_level': fatigue_level,
            'sample_count': len(self.speeds)
        }