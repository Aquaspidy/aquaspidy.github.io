"""
Tactical Recognition Module
Identifies offensive and defensive formations based on player positions
"""

import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from collections import deque


@dataclass
class Tactic:
    name: str
    type: str  # 'offense' or 'defense'
    confidence: float
    players: List[int]
    description: str
    counter: str  # Counter-play advice


class TacticalDetector:
    """Detects basketball tactics from player positions"""
    
    def __init__(self, court_length=28, court_width=15):
        self.court_length = court_length
        self.court_width = court_width
        self.frame_count = 0
        self.tactic_history = deque(maxlen=30)
        self.detected_tactics = []
        
        # Zone definitions (percentage of court)
        self.zones = {
            'top': {'x': (0.3, 0.7), 'y': (0.05, 0.30)},
            'mid': {'x': (0.2, 0.8), 'y': (0.30, 0.60)},
            'bottom': {'x': (0.1, 0.9), 'y': (0.60, 0.95)},
            'left_elbow': {'x': (0.15, 0.35), 'y': (0.25, 0.45)},
            'right_elbow': {'x': (0.65, 0.85), 'y': (0.25, 0.45)},
            'top_key': {'x': (0.35, 0.65), 'y': (0.05, 0.20)},
            'left_corner': {'x': (0.02, 0.20), 'y': (0.60, 0.85)},
            'right_corner': {'x': (0.80, 0.98), 'y': (0.60, 0.85)},
            'left_wing': {'x': (0.15, 0.35), 'y': (0.30, 0.50)},
            'right_wing': {'x': (0.65, 0.85), 'y': (0.30, 0.50)},
        }
    
    def update(self, home_players: List[Dict], away_players: List[Dict], possession: str = "Unknown") -> List[Tactic]:
        """Update detector with new frame data"""
        self.frame_count += 1
        detected = []
        
        # Detect defensive formations (both teams)
        detected.extend(self._detect_zone_defense(home_players, 'home'))
        detected.extend(self._detect_zone_defense(away_players, 'away'))
        
        # Detect offensive formations
        if possession == 'home':
            detected.extend(self._detect_horns(home_players, 'home'))
            detected.extend(self._detect_1_3_1(home_players, 'home'))
            detected.extend(self._detect_flex(home_players, 'home'))
        elif possession == 'away':
            detected.extend(self._detect_horns(away_players, 'away'))
            detected.extend(self._detect_1_3_1(away_players, 'away'))
            detected.extend(self._detect_flex(away_players, 'away'))
        
        # Store history
        for t in detected:
            self.tactic_history.append(t)
            self.detected_tactics.append(t)
        
        return detected
    
    def _get_players_in_zone(self, players: List[Dict], zone: Tuple) -> List[Dict]:
        """Get players within a zone (x_min, x_max, y_min, y_max)"""
        x_min, x_max, y_min, y_max = zone
        result = []
        for p in players:
            x = p.get('x', 0)
            y = p.get('y', 0)
            if x_min <= x <= x_max and y_min <= y <= y_max:
                result.append(p)
        return result
    
    def _detect_zone_defense(self, players: List[Dict], team: str) -> List[Tactic]:
        """Detect all zone defenses (2-3, 3-2, 1-2-2)"""
        if len(players) < 5:
            return []
        
        tactics = []
        
        # Get players in zones
        top_players = self._get_players_in_zone(players, (0.2, 0.8, 0.05, 0.30))
        bottom_players = self._get_players_in_zone(players, (0.1, 0.9, 0.55, 0.95))
        
        # 2-3 Zone Defense: 2 top, 3 bottom
        if len(top_players) >= 2 and len(bottom_players) >= 3:
            top_width = self._calculate_spread(top_players)
            bottom_width = self._calculate_spread(bottom_players)
            
            if bottom_width > 0.4 and top_width < 0.5:
                tactics.append(Tactic(
                    name="2-3 Zone Defense",
                    type="defense",
                    confidence=self._calculate_confidence(0.7, len(players)),
                    players=[p['id'] for p in players],
                    description="2 players at top, 3 at baseline",
                    counter="Attack the high post / free throw line area with a passer"
                ))
        
        # 3-2 Zone Defense: 3 top, 2 bottom
        if len(top_players) >= 3 and len(bottom_players) >= 2:
            top_width = self._calculate_spread(top_players)
            bottom_width = self._calculate_spread(bottom_players)
            
            if top_width > 0.4 and bottom_width < 0.4:
                tactics.append(Tactic(
                    name="3-2 Zone Defense",
                    type="defense",
                    confidence=self._calculate_confidence(0.6, len(players)),
                    players=[p['id'] for p in players],
                    description="3 players at top, 2 at baseline",
                    counter="Attack the corners with skip passes, crash offensive glass"
                ))
        
        # 1-2-2 Zone Defense (box-and-one variant)
        top_one = self._get_players_in_zone(players, (0.35, 0.65, 0.02, 0.15))
        wing_left = self._get_players_in_zone(players, (0.05, 0.30, 0.25, 0.50))
        wing_right = self._get_players_in_zone(players, (0.70, 0.95, 0.25, 0.50))
        bottom_two = self._get_players_in_zone(players, (0.10, 0.90, 0.70, 0.95))
        
        if len(top_one) >= 1 and len(wing_left) >= 1 and len(wing_right) >= 1 and len(bottom_two) >= 2:
            tactics.append(Tactic(
                name="1-2-2 Zone Defense",
                type="defense",
                confidence=self._calculate_confidence(0.55, len(players)),
                players=[p['id'] for p in players],
                description="1 top, 2 wings, 2 baseline",
                counter="Overload one side with 3 players, force rotation"
            ))
        
        return tactics
    
    def _detect_horns(self, players: List[Dict], team: str) -> List[Tactic]:
        """Detect Horns offense: 2 bigs at elbows"""
        if len(players) < 5:
            return []
        
        left_elbow = self._get_players_in_zone(players, (0.15, 0.35, 0.30, 0.45))
        right_elbow = self._get_players_in_zone(players, (0.65, 0.85, 0.30, 0.45))
        top_player = self._get_players_in_zone(players, (0.30, 0.70, 0.02, 0.15))
        
        if len(left_elbow) >= 1 and len(right_elbow) >= 1 and len(top_player) >= 1:
            return [Tactic(
                name="Horns",
                type="offense",
                confidence=self._calculate_confidence(0.65, len(players)),
                players=[p['id'] for p in players],
                description="2 bigs at elbows, guard at top",
                counter="Deny the high post entry, force guard to baseline"
            )]
        
        return []
    
    def _detect_1_3_1(self, players: List[Dict], team: str) -> List[Tactic]:
        """Detect 1-3-1 offense"""
        if len(players) < 5:
            return []
        
        top = self._get_players_in_zone(players, (0.30, 0.70, 0.02, 0.15))
        middle = self._get_players_in_zone(players, (0.15, 0.85, 0.25, 0.50))
        bottom = self._get_players_in_zone(players, (0.30, 0.70, 0.75, 0.95))
        
        if len(top) >= 1 and len(middle) >= 3 and len(bottom) >= 1:
            return [Tactic(
                name="1-3-1",
                type="offense",
                confidence=self._calculate_confidence(0.5, len(players)),
                players=[p['id'] for p in players],
                description="1 top, 3 across middle, 1 baseline",
                counter="Overload one side with 3 defenders, force skip pass"
            )]
        
        return []
    
    def _detect_flex(self, players: List[Dict], team: str) -> List[Tactic]:
        """Detect Flex offense: continuous screening action"""
        if len(players) < 5:
            return []
        
        # Flex: players are constantly moving in a pattern
        # We detect this by looking for motion and spacing
        # Simplified: check for 2 players in corners, 2 at wings, 1 at top
        top = self._get_players_in_zone(players, (0.30, 0.70, 0.02, 0.15))
        wings = self._get_players_in_zone(players, (0.05, 0.30, 0.30, 0.50)) + self._get_players_in_zone(players, (0.70, 0.95, 0.30, 0.50))
        corners = self._get_players_in_zone(players, (0.02, 0.20, 0.60, 0.85)) + self._get_players_in_zone(players, (0.80, 0.98, 0.60, 0.85))
        
        if len(top) >= 1 and len(wings) >= 2 and len(corners) >= 2:
            return [Tactic(
                name="Flex",
                type="offense",
                confidence=self._calculate_confidence(0.45, len(players)),
                players=[p['id'] for p in players],
                description="Continuous screening action, weak side cuts",
                counter="Switch all screens, deny baseline cuts"
            )]
        
        return []
    
    def _calculate_spread(self, players: List[Dict]) -> float:
        """Calculate horizontal spread of players"""
        if len(players) < 2:
            return 0
        x_positions = [p.get('x', 0) for p in players]
        return max(x_positions) - min(x_positions)
    
    def _calculate_confidence(self, base: float, player_count: int) -> float:
        """Calculate confidence based on base and number of players"""
        count_factor = min(1.0, player_count / 5)
        return min(0.95, base * count_factor)
    
    def get_detected_tactics(self) -> List[Tactic]:
        """Get all detected tactics"""
        return self.detected_tactics
    
    def get_current_tactics(self) -> List[Tactic]:
        """Get tactics detected in the last frame"""
        if self.tactic_history:
            return list(self.tactic_history)[-1] if isinstance(self.tactic_history[-1], list) else [self.tactic_history[-1]]
        return []
    
    def clear_tactics(self):
        """Clear all stored tactics"""
        self.detected_tactics.clear()
        self.tactic_history.clear()