import cv2
import numpy as np
from collections import deque
import time


class Triangulator:
    """
    Handles 3D reconstruction from multiple cameras
    """
    
    def __init__(self):
        # Camera parameters (will be set during calibration)
        self.camera_params = {}
        self.calibrated = False
        
        # Player tracking across cameras
        self.player_3d_positions = {}  # player_id -> (x, y, z)
        self.track_history = {}  # player_id -> deque of positions
        
    def add_camera(self, camera_id, camera_matrix, dist_coeffs, rotation, translation):
        """
        Add a camera with its calibration parameters
        
        Args:
            camera_id: int (0, 1, 2, ...)
            camera_matrix: 3x3 intrinsic matrix (K)
            dist_coeffs: distortion coefficients (1x5)
            rotation: 3x3 rotation matrix (R)
            translation: 3x1 translation vector (T)
        """
        self.camera_params[camera_id] = {
            'K': np.array(camera_matrix, dtype=np.float32),
            'dist': np.array(dist_coeffs, dtype=np.float32),
            'R': np.array(rotation, dtype=np.float32),
            'T': np.array(translation, dtype=np.float32),
            'P': None  # Projection matrix (will be computed)
        }
        self.calibrated = True
    
    def compute_projection_matrix(self, camera_id):
        """Compute projection matrix P = K [R|T]"""
        if camera_id not in self.camera_params:
            return None
        
        params = self.camera_params[camera_id]
        K = params['K']
        R = params['R']
        T = params['T']
        
        # Create [R|T] matrix (3x4)
        RT = np.hstack((R, T))
        P = K @ RT
        
        params['P'] = P
        return P
    
    def triangulate_point(self, point_left, point_right, cam_id_left, cam_id_right):
        """
        Triangulate a 3D point from two camera views
        
        Args:
            point_left: (x, y) in camera left
            point_right: (x, y) in camera right
            cam_id_left: camera ID for left view
            cam_id_right: camera ID for right view
        
        Returns:
            (x, y, z) in 3D world coordinates
        """
        if not self.calibrated:
            print("[Triangulation] Not calibrated")
            return None
        
        # Get projection matrices
        P_left = self.camera_params[cam_id_left]['P']
        P_right = self.camera_params[cam_id_right]['P']
        
        if P_left is None:
            P_left = self.compute_projection_matrix(cam_id_left)
        if P_right is None:
            P_right = self.compute_projection_matrix(cam_id_right)
        
        # Convert points to homogeneous coordinates
        pts_left = np.array([point_left[0], point_left[1]], dtype=np.float32)
        pts_right = np.array([point_right[0], point_right[1]], dtype=np.float32)
        
        # Triangulate
        pts_4d = cv2.triangulatePoints(P_left, P_right, pts_left, pts_right)
        
        # Convert from homogeneous to 3D
        pts_3d = pts_4d[:3] / pts_4d[3]
        
        return (float(pts_3d[0]), float(pts_3d[1]), float(pts_3d[2]))
    
    def triangulate_points(self, points_left, points_right, cam_id_left, cam_id_right):
        """
        Triangulate multiple points from two camera views
        
        Args:
            points_left: list of (x, y) points in camera left
            points_right: list of (x, y) points in camera right
            cam_id_left: camera ID for left view
            cam_id_right: camera ID for right view
        
        Returns:
            list of (x, y, z) 3D points
        """
        if len(points_left) != len(points_right):
            print("[Triangulation] Point count mismatch")
            return []
        
        results = []
        for pL, pR in zip(points_left, points_right):
            pt = self.triangulate_point(pL, pR, cam_id_left, cam_id_right)
            if pt:
                results.append(pt)
        
        return results
    
    def match_players_across_cameras(self, detections_left, detections_right, max_dist=100):
        """
        Match detected players between two camera views
        
        Args:
            detections_left: list of dicts with 'bbox', 'center' from camera left
            detections_right: list of dicts with 'bbox', 'center' from camera right
            max_dist: maximum pixel distance for matching
        
        Returns:
            list of (detection_left, detection_right) matched pairs
        """
        matches = []
        
        for detL in detections_left:
            best_match = None
            best_dist = float('inf')
            
            cxL, cyL = detL['center']
            
            for detR in detections_right:
                cxR, cyR = detR['center']
                
                # Distance between centers
                dist = np.sqrt((cxL - cxR)**2 + (cyL - cyR)**2)
                
                if dist < best_dist and dist < max_dist:
                    best_dist = dist
                    best_match = detR
            
            if best_match:
                matches.append((detL, best_match))
        
        return matches
    
    def update_player_3d(self, player_id, position_3d):
        """Update a player's 3D position"""
        self.player_3d_positions[player_id] = position_3d
        
        if player_id not in self.track_history:
            self.track_history[player_id] = deque(maxlen=30)
        self.track_history[player_id].append(position_3d)
    
    def get_player_3d(self, player_id):
        """Get a player's current 3D position"""
        return self.player_3d_positions.get(player_id, None)
    
    def get_track_history(self, player_id):
        """Get a player's 3D position history"""
        return list(self.track_history.get(player_id, []))
    
    def project_to_court(self, position_3d, court_dimensions=(28, 15)):
        """
        Project 3D position to 2D court coordinates (percentage)
        
        Args:
            position_3d: (x, y, z) in world coordinates
            court_dimensions: (length, width) of court in meters
        
        Returns:
            (x_percent, y_percent) on court (0-100%)
        """
        length, width = court_dimensions
        
        # Assuming court coordinates:
        # x: length direction (0 to length)
        # y: width direction (0 to width)
        # z: height (ignored for court projection)
        
        x = position_3d[0]
        y = position_3d[1]
        
        # Convert to percentage
        x_pct = (x / length) * 100
        y_pct = (y / width) * 100
        
        # Clamp to court bounds
        x_pct = max(0, min(100, x_pct))
        y_pct = max(0, min(100, y_pct))
        
        return (x_pct, y_pct)