"""
3D Shot Quality Analysis
Calculates real shot metrics using multi-camera triangulation:
- Release height (actual vertical position)
- Release angle (arc of the shot)
- Shot distance (3D distance from hoop)
- Defender proximity (closest defender distance)
- Shot quality score (composite metric)
"""

import numpy as np
import cv2
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque
import time


@dataclass
class ShotData:
    """Data for a single shot attempt"""
    player_id: int
    team: str
    position_3d: Tuple[float, float, float]  # (x, y, z) in meters
    release_height: float  # meters from ground
    release_angle: float   # degrees
    distance_to_hoop: float  # meters
    defender_distance: float  # meters (closest defender)
    timestamp: float
    shot_made: bool = False
    shot_quality: float = 0.0


class ShotQuality3D:
    """
    3D Shot Quality Analyzer using multi-camera triangulation
    """
    
    def __init__(self, config=None):
        # Court dimensions in meters (standard basketball court)
        self.court_width = 15.0  # meters (FIBA standard)
        self.court_length = 28.0  # meters (FIBA standard)
        
        # Hoop position (fixed in court coordinates)
        # Assuming hoop is at one end of the court
        self.hoop_position = (26.0, 7.5, 3.05)  # (x, y, z) in meters
        # Hoop height is 3.05m (FIBA standard)
        self.hoop_height = 3.05
        
        # Shot quality thresholds
        self.OPTIMAL_RELEASE_HEIGHT = 2.6  # meters (ideal release height)
        self.OPTIMAL_RELEASE_ANGLE = 55.0  # degrees (ideal arc)
        self.MAX_DISTANCE = 12.0  # meters (max 3pt range)
        self.MIN_DISTANCE = 1.5   # meters (too close is forced)
        
        # Camera calibration data (would come from multi-camera setup)
        self.camera_calibrations = {}
        self.triangulator = None
        
        # Shot history for each player
        self.shot_history: Dict[int, List[ShotData]] = {}
        
        # Recent shot events
        self.recent_shots: List[ShotData] = []
        self.max_recent_shots = 20
        
    def set_triangulator(self, triangulator):
        """Set the triangulator for 3D position estimation"""
        self.triangulator = triangulator
        
    def register_camera(self, camera_id: int, calibration_data: Dict):
        """Register a camera with its calibration data"""
        self.camera_calibrations[camera_id] = calibration_data
        
    def detect_shot_attempt(self, player_id: int, 
                           position_2d: Tuple[int, int],
                           ball_position: Optional[Tuple[int, int]] = None,
                           defenders: List[Dict] = None,
                           frame: np.ndarray = None) -> Optional[ShotData]:
        """
        Detect if a player is attempting a shot based on:
        - Player position relative to hoop
        - Ball trajectory (if available)
        - Arm elevation
        - Motion pattern
        """
        # Convert 2D position to 3D court coordinates
        pos_3d = self._convert_to_3d(player_id, position_2d)
        if pos_3d is None:
            return None
            
        # Calculate distance to hoop
        dist_to_hoop = self._calculate_distance_to_hoop(pos_3d)
        
        # Calculate release height and angle
        release_height = self._estimate_release_height(pos_3d, frame)
        release_angle = self._estimate_release_angle(pos_3d, ball_position)
        
        # Find closest defender
        defender_distance = self._find_closest_defender(pos_3d, defenders)
        
        # Calculate shot quality score
        shot_quality = self._calculate_shot_quality(
            release_height, release_angle, dist_to_hoop, defender_distance
        )
        
        # Create shot data
        shot = ShotData(
            player_id=player_id,
            team="Unknown",  # Would come from player tracking
            position_3d=pos_3d,
            release_height=release_height,
            release_angle=release_angle,
            distance_to_hoop=dist_to_hoop,
            defender_distance=defender_distance,
            timestamp=time.time(),
            shot_quality=shot_quality
        )
        
        # Store in history
        if player_id not in self.shot_history:
            self.shot_history[player_id] = []
        self.shot_history[player_id].append(shot)
        
        # Store in recent shots
        self.recent_shots.append(shot)
        if len(self.recent_shots) > self.max_recent_shots:
            self.recent_shots.pop(0)
            
        return shot
    
    def _convert_to_3d(self, player_id: int, position_2d: Tuple[int, int]) -> Optional[Tuple[float, float, float]]:
        """
        Convert 2D camera position to 3D court coordinates using triangulation
        """
        if self.triangulator is None:
            # Fallback: estimate 3D position from 2D
            # In reality, this would use multi-camera triangulation
            return self._estimate_3d_position(player_id, position_2d)
        
        # Use triangulator to get 3D position
        try:
            # This assumes triangulator can process this
            # The actual implementation depends on your triangulation system
            pos_3d = self.triangulator.get_3d_position(player_id, position_2d)
            return pos_3d
        except Exception as e:
            print(f"[3D] Triangulation failed: {e}")
            return self._estimate_3d_position(player_id, position_2d)
    
    def _estimate_3d_position(self, player_id: int, position_2d: Tuple[int, int]) -> Tuple[float, float, float]:
        """
        Fallback: Estimate 3D position from 2D using court mapping
        """
        x_pct = position_2d[0] / 960.0  # Assuming 960px width
        y_pct = position_2d[1] / 540.0  # Assuming 540px height
        
        # Map to court coordinates (approximate)
        x_3d = x_pct * self.court_length
        y_3d = y_pct * self.court_width
        z_3d = 1.5  # Approximate player height
        
        return (x_3d, y_3d, z_3d)
    
    def _calculate_distance_to_hoop(self, pos_3d: Tuple[float, float, float]) -> float:
        """Calculate 3D distance from player to hoop"""
        dx = pos_3d[0] - self.hoop_position[0]
        dy = pos_3d[1] - self.hoop_position[1]
        dz = 0  # Only horizontal distance for shot distance
        
        return np.sqrt(dx**2 + dy**2)
    
    def _estimate_release_height(self, pos_3d: Tuple[float, float, float], frame: np.ndarray = None) -> float:
        """
        Estimate release height based on player position and arm elevation
        In reality, this would use pose estimation
        """
        # Base height from court position
        base_height = pos_3d[2] if len(pos_3d) > 2 else 1.5
        
        # Add arm elevation (standard ~0.8m above shoulders)
        # In a real system, this would come from pose estimation
        release_height = base_height + 0.8
        
        # Clamp to reasonable range
        return max(1.8, min(3.2, release_height))
    
    def _estimate_release_angle(self, pos_3d: Tuple[float, float, float], 
                               ball_position: Optional[Tuple[int, int]]) -> float:
        """
        Estimate release angle based on ball trajectory
        """
        if ball_position:
            # If we have ball position, we can estimate angle
            # This would use ball trajectory tracking
            # For now, return a reasonable angle
            return 55.0
        
        # Default: optimal angle for mid-range shots
        distance = self._calculate_distance_to_hoop(pos_3d)
        if distance > 6.0:
            return 50.0  # 3pt shots have flatter arc
        else:
            return 55.0  # Mid-range
    
    def _find_closest_defender(self, pos_3d: Tuple[float, float, float], 
                              defenders: List[Dict]) -> float:
        """
        Find the closest defender and calculate distance
        """
        if not defenders:
            return 10.0  # No defenders, assume wide open
        
        closest_dist = float('inf')
        for defender in defenders:
            # Get defender position
            def_x = defender.get('x', 0)
            def_y = defender.get('y', 0)
            
            # Calculate distance
            dx = pos_3d[0] - def_x
            dy = pos_3d[1] - def_y
            dist = np.sqrt(dx**2 + dy**2)
            
            if dist < closest_dist:
                closest_dist = dist
        
        return closest_dist
    
    def _calculate_shot_quality(self, release_height: float, release_angle: float,
                               distance: float, defender_distance: float) -> float:
        """
        Calculate comprehensive shot quality score (0-100)
        """
        # Height score (optimal release height = 2.6m)
        height_score = 100 - abs(release_height - self.OPTIMAL_RELEASE_HEIGHT) * 50
        height_score = max(0, min(100, height_score))
        
        # Angle score (optimal release angle = 55 degrees)
        angle_score = 100 - abs(release_angle - self.OPTIMAL_RELEASE_ANGLE) * 2
        angle_score = max(0, min(100, angle_score))
        
        # Distance score (optimal is mid-range)
        if distance < 2.0:
            distance_score = 50  # Too close
        elif distance < 5.0:
            distance_score = 100 - (distance - 2.0) * 10  # 100 at 2m, decreasing
        elif distance < 7.0:
            distance_score = 100 - (distance - 5.0) * 10  # 70 at 7m
        else:
            distance_score = max(30, 100 - (distance - 7.0) * 15)  # Decreases for 3pt
        
        # Defender proximity score (closer = lower quality)
        defender_score = 100
        if defender_distance < 1.0:
            defender_score = 30  # Very contested
        elif defender_distance < 2.0:
            defender_score = 50  # Contested
        elif defender_distance < 3.0:
            defender_score = 70  # Moderately contested
        else:
            defender_score = 100  # Wide open
        
        # Weighted composite score
        shot_quality = (
            height_score * 0.25 +
            angle_score * 0.20 +
            distance_score * 0.30 +
            defender_score * 0.25
        )
        
        return max(0, min(100, shot_quality))
    
    def get_player_stats(self, player_id: int) -> Dict:
        """Get shot statistics for a specific player"""
        if player_id not in self.shot_history:
            return {}
        
        shots = self.shot_history[player_id]
        if not shots:
            return {}
        
        total_shots = len(shots)
        avg_quality = np.mean([s.shot_quality for s in shots])
        avg_distance = np.mean([s.distance_to_hoop for s in shots])
        
        # Categorize shots
        contested = sum(1 for s in shots if s.defender_distance < 2.0)
        open_shots = total_shots - contested
        
        return {
            'total_shots': total_shots,
            'avg_quality': round(avg_quality, 1),
            'avg_distance': round(avg_distance, 2),
            'contested': contested,
            'open': open_shots,
            'best_quality': max([s.shot_quality for s in shots]),
            'worst_quality': min([s.shot_quality for s in shots])
        }
    
    def get_team_stats(self, team: str) -> Dict:
        """Get shot statistics for a team"""
        # This would iterate through all players on the team
        # For now, return placeholder
        return {
            'total_shots': 0,
            'avg_quality': 0,
            'fg_percentage': 0
        }
    
    def get_recent_shots(self, n: int = 5) -> List[Dict]:
        """Get the most recent shots with details"""
        recent = self.recent_shots[-n:] if self.recent_shots else []
        
        result = []
        for shot in recent:
            result.append({
                'player_id': shot.player_id,
                'distance': round(shot.distance_to_hoop, 2),
                'release_height': round(shot.release_height, 2),
                'release_angle': round(shot.release_angle, 1),
                'defender_distance': round(shot.defender_distance, 2),
                'quality': round(shot.shot_quality, 1)
            })
        
        return result
    
    def get_shot_quality_summary(self) -> Dict:
        """Get summary of shot quality analysis"""
        if not self.recent_shots:
            return {
                'avg_quality': 0,
                'total_shots': 0,
                'contested_shots': 0,
                'open_shots': 0,
                'recommendations': ['No shot data available yet']
            }
        
        total = len(self.recent_shots)
        avg_quality = np.mean([s.shot_quality for s in self.recent_shots])
        contested = sum(1 for s in self.recent_shots if s.defender_distance < 2.0)
        open_shots = total - contested
        
        # Generate recommendations
        recommendations = []
        if avg_quality < 50:
            recommendations.append("Focus on taking higher quality shots")
        if contested > total * 0.4:
            recommendations.append("Too many contested shots - look for open looks")
        if avg_quality > 70 and open_shots > total * 0.5:
            recommendations.append("Great shot selection - keep moving the ball")
        
        return {
            'avg_quality': round(avg_quality, 1),
            'total_shots': total,
            'contested_shots': contested,
            'open_shots': open_shots,
            'recommendations': recommendations if recommendations else ['Continue finding good looks']
        }