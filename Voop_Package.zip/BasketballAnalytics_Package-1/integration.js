function updateDashboard(data) {
    console.log("Data received:", data);
    
    if (data.videoFrame) {
        var vid = document.getElementById("videoFeed");
        if (!vid) {
            vid = document.createElement("video");
            vid.id = "videoFeed";
            vid.autoplay = true;
            vid.muted = true;
            vid.style.cssText = "width:100%;height:100%;object-fit:contain;position:absolute;top:0;left:0;z-index:0;";
            var container = document.getElementById("videoContainer");
            if (container) container.prepend(vid);
        }
        vid.src = data.videoFrame;
    }
    
    if (data.players) {
        var overlay = document.getElementById("courtOverlay");
        if (overlay) {
            var dots = overlay.querySelectorAll(".player-dot");
            dots.forEach(function(el) {
                if (!el.closest(".camera") && !el.closest(".basket")) {
                    el.remove();
                }
            });
            
            if (data.players.home) {
                data.players.home.forEach(function(p) {
                    var el = document.createElement("div");
                    el.className = "player-dot home";
                    el.textContent = p.id;
                    el.style.left = Math.max(5, Math.min(95, p.x)) + "%";
                    el.style.top = Math.max(5, Math.min(95, p.y)) + "%";
                    var label = document.createElement("span");
                    label.className = "player-label";
                    label.textContent = "🏠 " + p.id;
                    el.appendChild(label);
                    overlay.appendChild(el);
                });
            }
            if (data.players.away) {
                data.players.away.forEach(function(p) {
                    var el = document.createElement("div");
                    el.className = "player-dot away";
                    el.textContent = p.id;
                    el.style.left = Math.max(5, Math.min(95, p.x)) + "%";
                    el.style.top = Math.max(5, Math.min(95, p.y)) + "%";
                    var label = document.createElement("span");
                    label.className = "player-label";
                    label.textContent = "✈️ " + p.id;
                    el.appendChild(label);
                    overlay.appendChild(el);
                });
            }
        }
    }
    
    if (data.stats) {
        if (data.stats.fps) {
            var el = document.getElementById("fpsDisplay");
            if (el) el.textContent = data.stats.fps;
        }
        if (data.stats.time) {
            var el = document.getElementById("timeLabel");
            if (el) el.textContent = data.stats.time + " / 48:00";
        }
        if (data.stats.possession) {
            var progressFill = document.getElementById("progressFill");
            if (progressFill && data.stats.possession.percent !== undefined) {
                progressFill.style.width = data.stats.possession.percent + "%";
            }
        }
    }
}

window.updateDashboard = updateDashboard;
console.log("Voop Dashboard ready");
