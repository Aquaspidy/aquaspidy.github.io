"""
Enhanced Events Detection Module
Detects Fast Break, Drive, Pass, Steal, Block
"""

import numpy as np
from collections import deque
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional

@dataclass
class EnhancedEvent:
    type: str
    time: float
    start_frame: int
    end_frame: int
    players: List[int]
    team: str
    detail: str
    confidence: float


class EnhancedEventDetector:
    """Detects advanced events from tracking data"""
    
    def __init__(self, fps=30, court_length=28, court_width=15):
        self.fps = fps
        self.dt = 1.0 / fps
        self.court_length = court_length
        self.court_width = court_width
        
        # Event storage
        self.events: List[EnhancedEvent] = []
        self.frame_count = 0
        
        # Detection state
        self.possession_history = deque(maxlen=60)  # Last 2 seconds
        self.team_positions = {
            'home': deque(maxlen=60),
            'away': deque(maxlen=60)
        }
        self.ball_positions = deque(maxlen=60)
        
        # Fast break tracking
        self.fast_break_state = {
            'active': False,
            'start_frame': 0,
            'start_pos': None,
            'players': [],
            'team': None
        }
        
        # Drive tracking
        self.drive_state = {
            'active': False,
            'start_frame': 0,
            'player_id': None,
            'team': None,
            'start_pos': None
        }
        
        # Pass tracking
        self.pass_candidates = []
        self.ball_owner = None  # Player ID with ball
        
        # Steal tracking
        self.steal_state = {
            'active': False,
            'start_frame': 0,
            'defender': None,
            'offender': None
        }
        
        # Block tracking
        self.block_state = {
            'active': False,
            'start_frame': 0,
            'blocker': None,
            'shooter': None
        }
    
    def update(self, home_players: List[Dict], away_players: List[Dict], 
               ball_pos: Optional[Tuple[float, float]] = None, 
               possession: str = "Unknown") -> List[EnhancedEvent]:
        """
        Update detector with new frame data
        
        Args:
            home_players: List of home player dicts with 'id', 'x', 'y'
            away_players: List of away player dicts with 'id', 'x', 'y'
            ball_pos: (x, y) position of ball (optional)
            possession: Current possession team ('home' or 'away')
        
        Returns:
            List of newly detected events
        """
        self.frame_count += 1
        
        new_events = []
        
        # Update history
        self.possession_history.append(possession)
        
        # Update team positions
        for p in home_players:
            if p.get('x') is not None and p.get('y') is not None:
                self.team_positions['home'].append((p['id'], p['x'], p['y']))
        
        for p in away_players:
            if p.get('x') is not None and p.get('y') is not None:
                self.team_positions['away'].append((p['id'], p['x'], p['y']))
        
        if ball_pos:
            self.ball_positions.append(ball_pos)
        
        # Detect events
        new_events.extend(self._detect_fast_break(home_players, away_players, ball_pos, possession))
        new_events.extend(self._detect_drive(home_players, away_players, ball_pos, possession))
        new_events.extend(self._detect_pass(home_players, away_players, ball_pos, possession))
        new_events.extend(self._detect_steal(home_players, away_players, ball_pos, possession))
        new_events.extend(self._detect_block(home_players, away_players, ball_pos, possession))
        
        # Add to events list
        for e in new_events:
            self.events.append(e)
        
        return new_events
    
    def _detect_fast_break(self, home_players, away_players, ball_pos, possession) -> List[EnhancedEvent]:
        """Detect fast break: quick transition after possession change"""
        events = []
        
        # Need ball position and possession
        if not ball_pos or possession == "Unknown":
            return events
        
        # Check if possession just changed
        if len(self.possession_history) > 10:
            prev_possessions = list(self.possession_history)[-10:-5]
            current_possessions = list(self.possession_history)[-5:]
            
            # Detect possession change
            prev_team = max(set(prev_possessions), key=prev_possessions.count) if prev_possessions else "Unknown"
            curr_team = max(set(current_possessions), key=current_possessions.count) if current_possessions else "Unknown"
            
            if prev_team != "Unknown" and curr_team != "Unknown" and prev_team != curr_team:
                # Possession changed!
                if not self.fast_break_state['active']:
                    # Check if team is moving quickly up court
                    team_players = home_players if curr_team == "home" else away_players
                    if len(team_players) >= 2:
                        # Check average speed of players
                        speeds = []
                        for p in team_players:
                            if p.get('speed'):
                                speeds.append(p['speed'])
                        
                        if speeds and np.mean(speeds) > 3.0:  # Fast movement
                            self.fast_break_state['active'] = True
                            self.fast_break_state['start_frame'] = self.frame_count
                            self.fast_break_state['start_pos'] = ball_pos
                            self.fast_break_state['players'] = [p['id'] for p in team_players[:3]]
                            self.fast_break_state['team'] = curr_team
        
        # Check if fast break completed or failed
        if self.fast_break_state['active']:
            duration = self.frame_count - self.fast_break_state['start_frame']
            
            # If it's been more than 3 seconds, check if it was successful
            if duration > 30:  # 1 second at 30fps
                # Check if ball advanced significantly
                if ball_pos and self.fast_break_state['start_pos']:
                    start_x = self.fast_break_state['start_pos'][0]
                    if abs(ball_pos[0] - start_x) > 5.0:  # Moved more than 5 meters
                        event = EnhancedEvent(
                            type="FastBreak",
                            time=self.frame_count / self.fps,
                            start_frame=self.fast_break_state['start_frame'],
                            end_frame=self.frame_count,
                            players=self.fast_break_state['players'],
                            team=self.fast_break_state['team'],
                            detail=f"Transition by {self.fast_break_state['team']}",
                            confidence=0.7
                        )
                        events.append(event)
                
                self.fast_break_state['active'] = False
        
        return events
    
    def _detect_drive(self, home_players, away_players, ball_pos, possession) -> List[EnhancedEvent]:
        """Detect drive: player attacks basket with speed"""
        events = []
        
        if possession == "Unknown":
            return events
        
        team_players = home_players if possession == "home" else away_players
        
        for p in team_players:
            player_id = p.get('id')
            speed = p.get('speed', 0)
            
            # Look for player moving fast toward basket
            if speed > 3.5:  # Fast movement
                # Check if moving toward basket (simplified: y direction)
                if p.get('vy') and p.get('vy') < -0.5:  # Moving up on court
                    if not self.drive_state['active']:
                        self.drive_state['active'] = True
                        self.drive_state['start_frame'] = self.frame_count
                        self.drive_state['player_id'] = player_id
                        self.drive_state['team'] = possession
                        self.drive_state['start_pos'] = (p['x'], p['y'])
            
            # Check if drive completed
            if self.drive_state['active'] and self.drive_state['player_id'] == player_id:
                duration = self.frame_count - self.drive_state['start_frame']
                
                if duration > 10 and duration < 60:  # 0.3 to 2 seconds
                    # Check if player got closer to basket
                    if self.drive_state['start_pos']:
                        start_y = self.drive_state['start_pos'][1]
                        if p.get('y') and p.get('y') < start_y - 2.0:  # Advanced toward basket
                            event = EnhancedEvent(
                                type="Drive",
                                time=self.frame_count / self.fps,
                                start_frame=self.drive_state['start_frame'],
                                end_frame=self.frame_count,
                                players=[player_id],
                                team=possession,
                                detail=f"Drive by player {player_id}",
                                confidence=0.65
                            )
                            events.append(event)
                            self.drive_state['active'] = False
        
        return events
    
    def _detect_pass(self, home_players, away_players, ball_pos, possession) -> List[EnhancedEvent]:
        """Detect pass: ball moves between players"""
        events = []
        
        # Simplified pass detection: if ball moves significantly and possession team changes
        if len(self.ball_positions) > 10:
            recent = list(self.ball_positions)[-10:]
            if len(recent) >= 2:
                # Check if ball moved a lot
                start = recent[0]
                end = recent[-1]
                distance = np.sqrt((end[0] - start[0])**2 + (end[1] - start[1])**2)
                
                if distance > 3.0:  # Ball moved more than 3 meters
                    # Find closest player to ball at start and end
                    all_players = home_players + away_players
                    
                    start_player = None
                    end_player = None
                    min_start_dist = float('inf')
                    min_end_dist = float('inf')
                    
                    for p in all_players:
                        if p.get('x') is not None and p.get('y') is not None:
                            dist_start = np.sqrt((p['x'] - start[0])**2 + (p['y'] - start[1])**2)
                            dist_end = np.sqrt((p['x'] - end[0])**2 + (p['y'] - end[1])**2)
                            
                            if dist_start < min_start_dist and dist_start < 2.0:
                                min_start_dist = dist_start
                                start_player = p['id']
                            
                            if dist_end < min_end_dist and dist_end < 2.0:
                                min_end_dist = dist_end
                                end_player = p['id']
                    
                    if start_player and end_player and start_player != end_player:
                        event = EnhancedEvent(
                            type="Pass",
                            time=self.frame_count / self.fps,
                            start_frame=self.frame_count - 10,
                            end_frame=self.frame_count,
                            players=[start_player, end_player],
                            team=possession,
                            detail=f"Pass {start_player} → {end_player}",
                            confidence=0.6
                        )
                        events.append(event)
        
        return events
    
    def _detect_steal(self, home_players, away_players, ball_pos, possession) -> List[EnhancedEvent]:
        """Detect steal: possession changes without pass"""
        events = []
        
        # Check for sudden possession change
        if len(self.possession_history) > 5:
            recent = list(self.possession_history)[-5:]
            if len(recent) >= 2:
                # If possession changed from home to away or vice versa
                if recent[0] != recent[-1] and recent[0] != "Unknown" and recent[-1] != "Unknown":
                    # Check if it happened quickly (within 2 frames)
                    if recent[0] != recent[1]:
                        # Find defender near ball
                        defending_team = away_players if recent[0] == "home" else home_players
                        
                        for d in defending_team:
                            if ball_pos and d.get('x') is not None and d.get('y') is not None:
                                dist_to_ball = np.sqrt((d['x'] - ball_pos[0])**2 + (d['y'] - ball_pos[1])**2)
                                if dist_to_ball < 1.5:
                                    event = EnhancedEvent(
                                        type="Steal",
                                        time=self.frame_count / self.fps,
                                        start_frame=self.frame_count - 2,
                                        end_frame=self.frame_count,
                                        players=[d['id']],
                                        team=recent[-1],
                                        detail=f"Steal by player {d['id']}",
                                        confidence=0.55
                                    )
                                    events.append(event)
                                    break
        
        return events
    
    def _detect_block(self, home_players, away_players, ball_pos, possession) -> List[EnhancedEvent]:
        """Detect block: defender deflects shot"""
        events = []
        
        # Simplified: if ball trajectory changes abruptly near basket
        if len(self.ball_positions) > 20:
            recent = list(self.ball_positions)[-20:]
            
            # Check if ball was moving toward basket
            if len(recent) >= 5:
                start = recent[0]
                end = recent[-1]
                
                # If ball was going up but suddenly changes direction
                if start[1] < end[1] and end[1] < 5.0:  # Moving up toward basket
                    # Check for defender near ball
                    all_players = home_players + away_players
                    for p in all_players:
                        if p.get('x') is not None and p.get('y') is not None:
                            dist_to_ball = np.sqrt((p['x'] - end[0])**2 + (p['y'] - end[1])**2)
                            if dist_to_ball < 1.5 and p.get('height', 0) > 1.9:
                                event = EnhancedEvent(
                                    type="Block",
                                    time=self.frame_count / self.fps,
                                    start_frame=self.frame_count - 10,
                                    end_frame=self.frame_count,
                                    players=[p['id']],
                                    team="away" if possession == "home" else "home",
                                    detail=f"Block by player {p['id']}",
                                    confidence=0.5
                                )
                                events.append(event)
                                break
        
        return events
    
    def get_events(self, event_type=None):
        """Get all detected events, optionally filtered by type"""
        if event_type:
            return [e for e in self.events if e.type == event_type]
        return self.events
    
    def get_event_summary(self):
        """Get summary of all events"""
        summary = {}
        for e in self.events:
            summary[e.type] = summary.get(e.type, 0) + 1
        return summary
    
    def clear_events(self):
        """Clear all stored events"""
        self.events.clear()