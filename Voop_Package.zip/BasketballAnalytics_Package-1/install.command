#!/bin/bash
cd "$(dirname "$0")"
echo "========================================="
echo "Basketball Analytics - Installation"
echo "========================================="
echo ""
echo "Installing required Python packages..."
pip3 install opencv-python PyQt6 ultralytics numpy
echo ""
echo "Done! You can now run Voop.app"
echo ""
read -p "Press Enter to close..."
