import unittest

import cv2
import numpy as np

from ball_tracker import BallTracker
from vision import LightingNormalizer


def make_frame(ball=None, distractor=None):
    """Synthetic court with texture representative of a noisy background."""
    rng = np.random.default_rng(42)
    frame = np.full((360, 640, 3), (70, 115, 155), dtype=np.uint8)
    noise = rng.normal(0, 10, frame.shape).astype(np.int16)
    frame = np.clip(frame.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    for point in (ball, distractor):
        if point is None:
            continue
        x, y = point
        cv2.circle(frame, (x, y), 10, (25, 105, 215), -1)  # orange leather in BGR
        cv2.circle(frame, (x, y), 10, (15, 65, 115), 1)    # dark outline/seam
        cv2.line(frame, (x - 8, y), (x + 8, y), (20, 55, 105), 1)
    return frame


class BallTrackerTests(unittest.TestCase):
    def test_prefers_the_motion_consistent_ball_over_a_same_colour_distractor(self):
        tracker = BallTracker()
        tracker.initialize(make_frame(ball=(120, 190)), (120, 190))

        result = tracker.update(make_frame(ball=(132, 192), distractor=(500, 65)))

        self.assertTrue(result.observed)
        self.assertIsNotNone(result.position)
        self.assertLess(np.linalg.norm(np.array(result.position) - np.array((132, 192))), 10)

    def test_holds_prediction_through_a_brief_occlusion_without_jumping_to_clutter(self):
        tracker = BallTracker()
        tracker.initialize(make_frame(ball=(200, 160)), (200, 160))
        tracker.update(make_frame(ball=(209, 161)))

        occluded = tracker.update(make_frame(distractor=(520, 80)))
        self.assertFalse(occluded.observed)
        self.assertIsNotNone(occluded.position)
        self.assertLess(np.linalg.norm(np.array(occluded.position) - np.array((220, 162))), 35)

        recovered = tracker.update(make_frame(ball=(228, 163), distractor=(520, 80)))
        self.assertTrue(recovered.observed)
        self.assertLess(np.linalg.norm(np.array(recovered.position) - np.array((228, 163))), 14)


class LightingNormalizerTests(unittest.TestCase):
    def test_stabilizes_a_large_exposure_change(self):
        base = make_frame(ball=(200, 160))
        dark = np.clip(base.astype(np.float32) * 0.45, 0, 255).astype(np.uint8)
        bright = np.clip(base.astype(np.float32) * 1.65, 0, 255).astype(np.uint8)
        normalizer = LightingNormalizer()

        stabilized_dark = normalizer.normalize(dark)
        stabilized_bright = normalizer.normalize(bright)
        dark_luma = float(np.median(cv2.cvtColor(stabilized_dark, cv2.COLOR_BGR2LAB)[..., 0]))
        bright_luma = float(np.median(cv2.cvtColor(stabilized_bright, cv2.COLOR_BGR2LAB)[..., 0]))

        self.assertLess(abs(dark_luma - bright_luma), 24)


if __name__ == "__main__":
    unittest.main()
