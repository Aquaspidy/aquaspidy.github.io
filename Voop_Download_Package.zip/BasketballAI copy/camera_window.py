import cv2
import numpy as np
from torch import layout
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
from PyQt6.QtCore import QThread, pyqtSignal, Qt
from PyQt6.QtGui import QImage, QPixmap


class CameraWindow(QWidget):
    def __init__(self, processor):
        super().__init__()
        self.processor = processor
        self.setWindowTitle("📷 Voop - Camera View (Click to learn colors)")
        self.setMinimumSize(960, 600)
        self.setStyleSheet("background-color: #0b0f1a;")
        
        layout = QVBoxLayout()
        
        # Two camera labels
        video_layout = QHBoxLayout()
        
        self.video_label_1 = QLabel()
        self.video_label_1.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_label_1.setStyleSheet("background-color: #0a0e16; border: 2px solid #2a3344; border-radius: 8px;")
        self.video_label_1.setMinimumSize(450, 400)
        self.video_label_1.mousePressEvent = self.on_video_click
        
        self.video_label_2 = QLabel()
        self.video_label_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_label_2.setStyleSheet("background-color: #0a0e16; border: 2px solid #2a3344; border-radius: 8px;")
        self.video_label_2.setMinimumSize(450, 400)
        self.video_label_2.mousePressEvent = lambda event: None
        
        video_layout.addWidget(self.video_label_1)
        video_layout.addWidget(self.video_label_2)
        
        layout.addLayout(video_layout)
        
        # Status bar
        self.status_label = QLabel("📷 Camera view - Click on players to learn jersey colors")
        self.status_label.setStyleSheet("color: #c8d0dc; padding: 8px; font-size: 13px;")
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        self.show()
    
    def on_video_click(self, event):
        """Handle click on video - learn colors OR learn ball"""
        if not self.processor:
            return

        # Get click position
        label = self.video_label_1

        x = event.position().x()
        y = event.position().y()

        pixmap = label.pixmap()
        if pixmap is None:
            return

        label_w = label.width()
        label_h = label.height()
        
        pix_w = pixmap.width()
        pix_h = pixmap.height()

        if pix_w == 0 or pix_h == 0:
            return
        offset_x = (label_w - pix_w) // 2
        offset_y = (label_h - pix_h) // 2
        
        click_x = x - offset_x
        click_y = y - offset_y
        
        frame_w = self.processor.config.frame_width
        frame_h = self.processor.config.frame_height
        scale_x = frame_w / pix_w
        scale_y = frame_h / pix_h
        
        fx = int(click_x * scale_x)
        fy = int(click_y * scale_y)
        
        # Check if ball learning mode is active
        if hasattr(self.processor, 'parent') and self.processor.parent:
            if hasattr(self.processor.parent, 'learning_ball') and self.processor.parent.learning_ball:
                # Set ball position
                if self.processor.parent.set_ball_position(fx, fy):
                    self.status_label.setText(f"🏀 Ball learned at ({fx}, {fy})")
                    return
        
        # If learning mode is active, use for color learning
        if self.processor.learning_active:
            self.processor.process_click(fx, fy, frame_w, frame_h)
    
    def _display_frame_to_label(self, frame, label):
        """Display a frame on a QLabel without extra overlays."""
        if frame is None:
            return

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        qt_img = QImage(rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_img)

        scaled = pixmap.scaled(
            label.width() - 20,
            label.height() - 20,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        label.setPixmap(scaled)

    def update_frame(self, frame):
        """Show the raw camera frame on both labels."""
        if frame is None:
            return

        self._display_frame_to_label(frame, self.video_label_1)
        self._display_frame_to_label(frame, self.video_label_2)
    
    def set_status(self, text):
        self.status_label.setText(text)
    
    def closeEvent(self, event):
        """Handle window close event"""
        event.accept()

    def update_camera(self, camera_id, frame):
        """Draw independent overlays for each camera."""
        if frame is None:
            return

        display = frame.copy()
        height, width = display.shape[:2]

        engine = getattr(self.processor, "engine", None)
        tracked_players = getattr(engine, "tracked_players", {}) if engine else {}

        if not hasattr(self, "_cam0_cached_players"):
            self._cam0_cached_players = {}

        if not hasattr(self, "_cam1_counter"):
            self._cam1_counter = 0

        if not hasattr(self, "_cam1_detections"):
            self._cam1_detections = {"westy": [], "opp": []}

        if camera_id == 0:
            # Camera 0: only keep/update its own boxes.
            # Do not let Camera 1's detections create new Camera 0 boxes.
            cam0_snapshot = {}

            initial_seed = not self._cam0_cached_players

            for pid, pdata in list(tracked_players.items()):
                source = pdata.get("camera_id", pdata.get("source_camera"))

                if source is not None:
                    try:
                        if int(source) != 0:
                            continue
                    except Exception:
                        pass
                elif not initial_seed and pid not in self._cam0_cached_players:
                    # Don't add brand-new players from unknown source after startup.
                    continue

                box = pdata.get("last_box")
                if box:
                    cam0_snapshot[pid] = {
                        "last_box": [int(v) for v in box],
                        "team_locked": pdata.get("team_locked"),
                        "team": pdata.get("team"),
                        "id": pid,
                    }
                elif pid in self._cam0_cached_players:
                    # Keep old Camera 0 box if current frame has no box
                    cam0_snapshot[pid] = self._cam0_cached_players[pid]

            self._cam0_cached_players = cam0_snapshot

            for pid, pdata in self._cam0_cached_players.items():
                box = pdata.get("last_box")
                if not box:
                    continue

                x1, y1, x2, y2 = [int(v) for v in box]
                x1 = int(np.clip(x1, 0, width - 1))
                y1 = int(np.clip(y1, 0, height - 1))
                x2 = int(np.clip(x2, 0, width - 1))
                y2 = int(np.clip(y2, 0, height - 1))

                team = pdata.get("team_locked") or pdata.get("team") or "Unknown"
                team_key = str(team).strip().lower()

                if team_key in ("westy", "home", "home team"):
                    color = (0, 255, 255)
                    label_text = f"Home {pid}"
                elif team_key in ("opponent", "away", "away team"):
                    color = (0, 0, 255)
                    label_text = f"Away {pid}"
                else:
                    color = (180, 180, 180)
                    label_text = f"P{pid}"

                cv2.rectangle(display, (x1, y1), (x2, y2), color, 2)
                cv2.putText(display, label_text, (x1, y1 - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        else:
            # Camera 1: use its own cached detections only
            self._cam1_counter += 1

            should_refresh = self._cam1_counter <= 1 or self._cam1_counter % 10 == 0

            # The primary processor owns ``engine``.  A secondary preview must
            # never run inference against that same mutable state, because the
            # two camera feeds would otherwise compete for player identities.
            preview_engine = None
            manager = getattr(self.processor, "camera_manager", None)
            worker = getattr(manager, "workers", {}).get(camera_id) if manager else None
            if worker is not None:
                preview_engine = worker.engine

            if should_refresh and preview_engine is not None and hasattr(preview_engine, "_process_detections"):
                t1_range = ([0, 0, 0], [0, 0, 0])
                t2_range = ([0, 0, 0], [0, 0, 0])

                westy_players, opp_players, _ = preview_engine._process_detections(
                    display,
                    getattr(worker, "frame_count", 0),
                    t1_range,
                    t2_range,
                )

                self._cam1_detections["westy"] = westy_players
                self._cam1_detections["opp"] = opp_players
            detections = self._cam1_detections
            all_players = detections["westy"] + detections["opp"]

            for player in all_players:
                team = player.get("team") or player.get("team_locked") or "Unknown"
                box = player.get("box", [0, 0, 0, 0])
                if not box:
                    continue

                x1, y1, x2, y2 = [int(v) for v in box]
                x1 = int(np.clip(x1, 0, width - 1))
                y1 = int(np.clip(y1, 0, height - 1))
                x2 = int(np.clip(x2, 0, width - 1))
                y2 = int(np.clip(y2, 0, height - 1))

                team_key = str(team).strip().lower()
                if team_key in ("westy", "home", "home team"):
                    color = (0, 255, 255)
                    label_text = f"Home {player.get('id', '?')}"
                elif team_key in ("opponent", "away", "away team"):
                    color = (0, 0, 255)
                    label_text = f"Away {player.get('id', '?')}"
                else:
                    color = (180, 180, 180)
                    label_text = f"P{player.get('id', '?')}"

                cv2.rectangle(display, (x1, y1), (x2, y2), color, 2)
                cv2.putText(display, label_text, (x1, y1 - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        if engine is not None and hasattr(engine, "ball_position") and engine.ball_position is not None:
            bx, by = engine.ball_position
            cv2.circle(display, (int(bx), int(by)), 10, (0, 255, 0), 3)
            cv2.putText(display, "BALL", (int(bx) + 12, int(by)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        if camera_id == 0:
            label = self.video_label_1
        else:
            label = self.video_label_2

        self._display_frame_to_label(display, label)
