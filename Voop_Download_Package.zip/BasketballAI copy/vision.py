"""Small, dependency-light vision utilities used by the live processors."""

from __future__ import annotations

import cv2
import numpy as np


class LightingNormalizer:
    """Reduce exposure flicker while preserving jersey and ball colour cues.

    A single normalizer belongs to each camera stream.  It establishes a
    reference luminance from the first valid frames and only slowly adapts that
    reference afterwards, so automatic camera exposure does not cause the
    colour classifier to oscillate from frame to frame.
    """

    def __init__(
        self,
        *,
        adaptation: float = 0.025,
        min_gain: float = 0.35,
        max_gain: float = 2.20,
    ) -> None:
        self.adaptation = adaptation
        self.min_gain = min_gain
        self.max_gain = max_gain
        self._reference_luminance: float | None = None
        self._clahe = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8))

    def reset(self) -> None:
        self._reference_luminance = None

    def normalize(self, frame: np.ndarray) -> np.ndarray:
        """Return a colour-balanced frame with temporally stable luminance."""
        if frame is None or frame.size == 0:
            return frame
        if frame.ndim != 3 or frame.shape[2] != 3:
            return frame

        # Neutralise modest white-balance shifts without allowing one unusual
        # frame (for example, a scoreboard close-up) to radically recolour it.
        bgr = frame.astype(np.float32)
        channel_means = bgr.reshape(-1, 3).mean(axis=0)
        neutral_mean = float(np.mean(channel_means))
        if neutral_mean > 1:
            gains = np.clip(neutral_mean / np.maximum(channel_means, 1.0), 0.88, 1.12)
            bgr *= gains
        balanced = np.clip(bgr, 0, 255).astype(np.uint8)

        lab = cv2.cvtColor(balanced, cv2.COLOR_BGR2LAB)
        luminance, a_channel, b_channel = cv2.split(lab)
        median_luminance = float(np.median(luminance))

        if median_luminance < 1:
            return balanced
        if self._reference_luminance is None:
            self._reference_luminance = median_luminance
        else:
            # Adapt only a little.  Rapid changes are typically camera auto-
            # exposure, while sustained changes can legitimately be the venue.
            self._reference_luminance = (
                (1.0 - self.adaptation) * self._reference_luminance
                + self.adaptation * median_luminance
            )

        gain = float(
            np.clip(self._reference_luminance / median_luminance, self.min_gain, self.max_gain)
        )
        corrected_luminance = np.clip(luminance.astype(np.float32) * gain, 0, 255).astype(np.uint8)

        # A restrained local correction recovers detail in shadows without the
        # aggressive colour/contrast changes that make learned jerseys drift.
        local_luminance = self._clahe.apply(corrected_luminance)
        corrected_luminance = cv2.addWeighted(corrected_luminance, 0.78, local_luminance, 0.22, 0)
        return cv2.cvtColor(
            cv2.merge([corrected_luminance, a_channel, b_channel]), cv2.COLOR_LAB2BGR
        )
