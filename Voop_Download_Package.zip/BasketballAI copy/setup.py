from setuptools import setup

APP = ['app.py']
DATA_FILES = ['varsity_logic.py', 'ball_tracker.py', 'vision.py']
OPTIONS = {
    'argv_emulation': False,
    'packages': ['cv2', 'numpy', 'PyQt6', 'ultralytics', 'torch', 'PIL'],
    'includes': ['varsity_logic', 'ball_tracker', 'vision'],
    'excludes': ['matplotlib', 'pandas', 'jupyter'],
    'plist': {
        'CFBundleName': 'BasketballAnalytics',
        'CFBundleDisplayName': 'Basketball Analytics Pro',
        'CFBundleIdentifier': 'com.voop.basketball',
        'CFBundleVersion': '1.0.0',
        'CFBundleShortVersionString': '1.0.0',
        'NSHighResolutionCapable': True,
        'LSUIElement': False,
        'CFBundleIconFile': 'app_icon.icns',  # Optional - add your own icon
    },
    'site_packages': True,
    'semi_standalone': False,
    'strip': False,
}

setup(
    app=APP,
    data_files=DATA_FILES,
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
)
