"""Robust single-camera basketball tracking.

The tracker intentionally combines colour, ball geometry, and motion.  A
colour-only detector will eventually jump to a jersey, logo, or court marking
that happens to be orange; those proposals are rejected unless they also make
sense relative to the predicted ball path.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np


Point = Tuple[int, int]


@dataclass(frozen=True)
class BallTrackResult:
    position: Optional[Point]
    observed: bool
    confidence: float
    misses: int


class BallTracker:
    """Track a manually seeded ball through clutter and brief occlusions."""

    def __init__(self, max_misses: int = 18) -> None:
        self.max_misses = max_misses
        self.position: Optional[np.ndarray] = None
        self.velocity = np.zeros(2, dtype=np.float32)
        self.color_mean: Optional[np.ndarray] = None
        self.color_std: Optional[np.ndarray] = None
        self.expected_area = 180.0
        self.misses = 0
        self.last_confidence = 0.0

    @property
    def active(self) -> bool:
        return self.position is not None and self.color_mean is not None

    def reset(self) -> None:
        self.position = None
        self.velocity = np.zeros(2, dtype=np.float32)
        self.color_mean = None
        self.color_std = None
        self.misses = 0
        self.last_confidence = 0.0

    def initialize(self, frame: np.ndarray, point: Point, radius: int = 10) -> BallTrackResult:
        """Seed the appearance model from a click near the centre of the ball."""
        if frame is None or frame.size == 0:
            self.reset()
            return BallTrackResult(None, False, 0.0, 0)

        height, width = frame.shape[:2]
        x = int(np.clip(point[0], 0, width - 1))
        y = int(np.clip(point[1], 0, height - 1))
        radius = int(np.clip(radius, 6, max(6, min(width, height) // 12)))

        x1, x2 = max(0, x - radius), min(width, x + radius + 1)
        y1, y2 = max(0, y - radius), min(height, y + radius + 1)
        roi = frame[y1:y2, x1:x2]
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

        circle = np.zeros(roi.shape[:2], dtype=np.uint8)
        cv2.circle(circle, (x - x1, y - y1), max(3, int(radius * 0.62)), 255, -1)
        samples = hsv[circle > 0]
        # The orange/brown leather is the stable part of a basketball.  Avoid
        # learning the dark seams and a bright background from the click ROI.
        if len(samples):
            sat_floor = np.percentile(samples[:, 1], 30)
            value_floor = np.percentile(samples[:, 2], 20)
            colourful = samples[(samples[:, 1] >= sat_floor) & (samples[:, 2] >= value_floor)]
            if len(colourful) >= 8:
                samples = colourful
        if len(samples) == 0:
            self.reset()
            return BallTrackResult(None, False, 0.0, 0)

        self.color_mean = np.median(samples, axis=0).astype(np.float32)
        median_abs_deviation = np.median(np.abs(samples - self.color_mean), axis=0)
        self.color_std = np.maximum(1.4826 * median_abs_deviation, np.array([3.0, 10.0, 12.0]))
        self.position = np.array([float(x), float(y)], dtype=np.float32)
        self.velocity = np.zeros(2, dtype=np.float32)
        self.expected_area = float(np.pi * radius * radius)
        self.misses = 0
        self.last_confidence = 1.0
        return BallTrackResult((x, y), True, 1.0, 0)

    @staticmethod
    def _hue_distance(hue: np.ndarray, reference: float) -> np.ndarray:
        difference = np.abs(hue.astype(np.float32) - reference)
        return np.minimum(difference, 180.0 - difference)

    @staticmethod
    def _circular_hue_blend(old_hue: float, new_hue: float, weight: float) -> float:
        old_angle = old_hue * np.pi / 90.0
        new_angle = new_hue * np.pi / 90.0
        x = (1.0 - weight) * np.cos(old_angle) + weight * np.cos(new_angle)
        y = (1.0 - weight) * np.sin(old_angle) + weight * np.sin(new_angle)
        return float((np.arctan2(y, x) * 90.0 / np.pi) % 180.0)

    def _colour_mask(self, hsv: np.ndarray) -> np.ndarray:
        assert self.color_mean is not None and self.color_std is not None
        hue_tolerance = float(np.clip(3.2 * self.color_std[0] + 7.0, 10.0, 28.0))
        saturation_floor = int(max(20, self.color_mean[1] - max(38.0, 3.2 * self.color_std[1])))
        value_floor = int(max(18, self.color_mean[2] - max(52.0, 3.5 * self.color_std[2])))
        hue_ok = self._hue_distance(hsv[..., 0], float(self.color_mean[0])) <= hue_tolerance
        mask = np.where(
            hue_ok & (hsv[..., 1] >= saturation_floor) & (hsv[..., 2] >= value_floor), 255, 0
        ).astype(np.uint8)
        kernel = np.ones((3, 3), dtype=np.uint8)
        return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)

    def _predicted_position(self, width: int, height: int) -> Optional[np.ndarray]:
        if self.position is None:
            return None
        predicted = self.position + self.velocity
        return np.array(
            [np.clip(predicted[0], 0, width - 1), np.clip(predicted[1], 0, height - 1)],
            dtype=np.float32,
        )

    def _appearance_distance(self, hsv: np.ndarray, contour: np.ndarray) -> float:
        assert self.color_mean is not None
        contour_mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        cv2.drawContours(contour_mask, [contour], -1, 255, -1)
        pixels = hsv[contour_mask > 0]
        if len(pixels) == 0:
            return 1.0
        observed = np.median(pixels, axis=0)
        hue_error = float(self._hue_distance(np.array([observed[0]]), self.color_mean[0])[0]) / 35.0
        saturation_error = abs(float(observed[1] - self.color_mean[1])) / 130.0
        return min(1.0, 0.78 * hue_error + 0.22 * saturation_error)

    def _adapt_appearance(self, hsv: np.ndarray, contour: np.ndarray) -> None:
        assert self.color_mean is not None and self.color_std is not None
        contour_mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        cv2.drawContours(contour_mask, [contour], -1, 255, -1)
        pixels = hsv[contour_mask > 0]
        if len(pixels) < 8:
            return
        sat_floor = np.percentile(pixels[:, 1], 25)
        pixels = pixels[pixels[:, 1] >= sat_floor]
        if len(pixels) < 5:
            return
        observed_mean = np.median(pixels, axis=0).astype(np.float32)
        observed_std = np.maximum(
            1.4826 * np.median(np.abs(pixels - observed_mean), axis=0), np.array([3.0, 10.0, 12.0])
        )
        self.color_mean[0] = self._circular_hue_blend(float(self.color_mean[0]), float(observed_mean[0]), 0.08)
        self.color_mean[1:] = 0.92 * self.color_mean[1:] + 0.08 * observed_mean[1:]
        self.color_std = 0.92 * self.color_std + 0.08 * observed_std

    def update(self, frame: np.ndarray) -> BallTrackResult:
        """Return the observed or predicted ball position for this frame."""
        if not self.active or frame is None or frame.size == 0:
            return BallTrackResult(None, False, 0.0, self.misses)

        height, width = frame.shape[:2]
        predicted = self._predicted_position(width, height)
        if predicted is None:
            return BallTrackResult(None, False, 0.0, self.misses)
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = self._colour_mask(hsv)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        speed = float(np.linalg.norm(self.velocity))
        gate = min(0.30 * np.hypot(width, height), max(48.0, 34.0 + speed * 2.2 + self.misses * 18.0))
        min_area = max(5.0, self.expected_area * 0.045)
        max_area = max(1_800.0, self.expected_area * 5.5)
        best: tuple[float, np.ndarray, np.ndarray, float] | None = None

        for contour in contours:
            area = float(cv2.contourArea(contour))
            if not min_area <= area <= max_area:
                continue
            x, y, candidate_width, candidate_height = cv2.boundingRect(contour)
            if candidate_width < 2 or candidate_height < 2:
                continue
            aspect = candidate_width / float(candidate_height)
            if not 0.35 <= aspect <= 2.8:
                continue
            moments = cv2.moments(contour)
            if moments["m00"] == 0:
                continue
            centre = np.array(
                [moments["m10"] / moments["m00"], moments["m01"] / moments["m00"]], dtype=np.float32
            )
            distance = float(np.linalg.norm(centre - predicted))
            if distance > gate:
                continue

            perimeter = float(cv2.arcLength(contour, True))
            circularity = 4.0 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0.0
            shape_error = min(1.0, abs(np.log(aspect)) / 1.2 + max(0.0, 0.55 - circularity))
            area_error = min(1.0, abs(np.log((area + 1.0) / (self.expected_area + 1.0))) / 3.2)
            appearance_error = self._appearance_distance(hsv, contour)
            score = (
                0.48 * (distance / gate) ** 2
                + 0.27 * appearance_error
                + 0.15 * shape_error
                + 0.10 * area_error
            )
            if best is None or score < best[0]:
                best = (score, centre, contour, area)

        if best is not None and best[0] <= 0.74:
            score, observed, contour, area = best
            previous = self.position.copy() if self.position is not None else observed
            self.position = 0.68 * observed + 0.32 * predicted
            observed_velocity = self.position - previous
            self.velocity = 0.60 * self.velocity + 0.40 * observed_velocity
            self.expected_area = 0.90 * self.expected_area + 0.10 * area
            self.misses = 0
            self.last_confidence = max(0.0, min(1.0, 1.0 - score))
            if score < 0.42:
                self._adapt_appearance(hsv, contour)
            point = (int(round(self.position[0])), int(round(self.position[1])))
            return BallTrackResult(point, True, self.last_confidence, 0)

        # Preserve a physically plausible prediction during an occlusion rather
        # than jumping to an unrelated colour match in a noisy background.
        self.position = predicted
        self.velocity *= 0.86
        self.misses += 1
        self.last_confidence *= 0.82
        if self.misses > self.max_misses:
            self.position = None
            return BallTrackResult(None, False, 0.0, self.misses)
        point = (int(round(predicted[0])), int(round(predicted[1])))
        return BallTrackResult(point, False, self.last_confidence, self.misses)
