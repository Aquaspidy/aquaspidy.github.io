#!/bin/bash

# Voop - Simple Launcher

cd "$(dirname "$0")"

echo "🏀 Starting Voop..."
python3 app.py