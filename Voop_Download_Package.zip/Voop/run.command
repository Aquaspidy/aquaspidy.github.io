#!/bin/bash

# Voop - Launcher for macOS
# This script launches the Voop app

echo "=========================================="
echo "        🏀 VOOP - LAUNCHER"
echo "=========================================="
echo ""

# Get the directory where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

echo "📁 Running from: $DIR"
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed!"
    echo "   Please install Python 3 from: https://www.python.org/downloads/"
    echo "   Or run: brew install python"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"
echo ""

# Check if dependencies are installed
if ! python3 -c "import cv2" &> /dev/null; then
    echo "⚠️ Dependencies not found!"
    echo "   Please run install.command first to install all required libraries."
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

echo "✅ Dependencies found"
echo ""

echo "🚀 Starting Voop..."
echo "   Press Q to quit"
echo "   Press H to flip attack direction"
echo "   Press R to generate timeout report"
echo ""

# Run the app
python3 app.py

echo ""
echo "=========================================="
echo "   VOOP HAS CLOSED"
echo "=========================================="
echo ""

read -p "Press Enter to exit..."