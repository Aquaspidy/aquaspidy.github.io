#!/bin/bash

# Voop - One-Click Installer for macOS
# This script installs all required dependencies

echo "=========================================="
echo "        🏀 VOOP - INSTALLER"
echo "=========================================="
echo ""

# Get the directory where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

echo "📁 Installing in: $DIR"
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed!"
    echo "   Please install Python 3 from: https://www.python.org/downloads/"
    echo "   Or run: brew install python"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"
echo ""

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "⚠️ pip3 not found, installing..."
    python3 -m ensurepip --upgrade
fi

echo "📦 Installing required libraries..."
echo "   This may take 5-10 minutes..."
echo ""

# Install from requirements.txt
if [ -f "requirements.txt" ]; then
    pip3 install -r requirements.txt --upgrade
else
    pip3 install opencv-python numpy PyQt6 PyQt6-WebEngine ultralytics torch torchvision scipy matplotlib Pillow --upgrade
fi

echo ""
echo "=========================================="
echo "✅ INSTALLATION COMPLETE!"
echo "=========================================="
echo ""
echo "🚀 To run Voop, double-click: run.command"
echo ""

read -p "Press Enter to exit..."