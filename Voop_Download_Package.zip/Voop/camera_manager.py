import cv2
import numpy as np
from PyQt6.QtCore import QThread, pyqtSignal, QMutex, QWaitCondition
from varsity_logic import AppConfig, VarsityAIEngine, normalize_lighting
import time
from triangulation import Triangulator

class CameraWorker(QThread):
    frame_ready = pyqtSignal(object, int)  # (frame, camera_id)
    status_update = pyqtSignal(str, int)   # (message, camera_id)
    error_occurred = pyqtSignal(str, int)  # (error, camera_id)
    
    def __init__(self, camera_id, config):
        super().__init__()
        self.camera_id = camera_id
        self.config = config
        self.running = True
        self.cap = None
        self.engine = VarsityAIEngine(config)
        self.frame_count = 0
        self.fps = 0
        self.last_frame = None
        
    def setup(self):
        try:
            if not self.engine._init_model():
                self.error_occurred.emit("Failed to load YOLO model", self.camera_id)
                return False
            
            self.cap = cv2.VideoCapture(self.camera_id)
            if not self.cap.isOpened():
                self.error_occurred.emit(f"Cannot open camera {self.camera_id}", self.camera_id)
                return False
            
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.frame_width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.frame_height)
            
            if self.engine.court_calibrator.court_polygon is None:
                self.engine.court_calibrator.court_polygon = np.array([
                    [0, 0],
                    [self.config.frame_width, 0],
                    [self.config.frame_width, self.config.frame_height],
                    [0, self.config.frame_height]
                ], dtype=np.int32)
            
            return True
        except Exception as e:
            self.error_occurred.emit(str(e), self.camera_id)
            return False
    
    def run(self):
        if not self.setup():
            return
        
        self.status_update.emit(f"Camera {self.camera_id} ready", self.camera_id)
        
        for _ in range(10):
            self.cap.read()
        
        while self.running and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            
            frame = cv2.resize(frame, (self.config.frame_width, self.config.frame_height))
            frame = normalize_lighting(frame)
            self.last_frame = frame.copy()
            self.frame_ready.emit(frame, self.camera_id)
            
            self.frame_count += 1
            time.sleep(0.03)
        
        if self.cap:
            self.cap.release()
    
    def stop(self):
        self.running = False
        self.wait()


class CameraManager:
    """Manages multiple camera workers"""
    
    def __init__(self, config):
        self.config = config
        self.workers = {}
        self.active_cameras = []
        self.primary_camera_id = None
        self.triangulator = Triangulator()
        self.court_dimensions = (28, 15)
        self.latest_frames = {}
        self.detections = {}
        self.triangulated_players = []
        self.processing_multi_cam = False
        self.last_multi_cam_time = 0
        self.multi_cam_interval = 0.15
        self._init_triangulator()
        self.camera_window = None

    def _init_triangulator(self):
        """Initialize triangulator with default camera parameters"""
        import numpy as np
        K = np.array([[1000, 0, 320], [0, 1000, 240], [0, 0, 1]], dtype=np.float32)
        dist = np.zeros(5, dtype=np.float32)
        R = np.eye(3, dtype=np.float32)
        T0 = np.array([[0], [0], [0]], dtype=np.float32)
        T1 = np.array([[1.0], [0], [0]], dtype=np.float32)
        
        self.triangulator.add_camera(0, K, dist, R, T0)
        self.triangulator.add_camera(1, K, dist, R, T1)
        self.triangulator.compute_projection_matrix(0)
        self.triangulator.compute_projection_matrix(1)
        print("[Triangulator] Initialized with default parameters")

    def detect_cameras(self, max_cameras=10):
        """
        Detect every available camera.
        """

        available = []

        print("\n========== CAMERA SCAN ==========")

        for i in range(max_cameras):

            cap = cv2.VideoCapture(i)

            if cap.isOpened():

                ret, frame = cap.read()

                if ret:
                    h, w = frame.shape[:2]
                    print(f"Camera {i}: OK ({w}x{h})")
                    available.append(i)
                else:
                    print(f"Camera {i}: Opened but cannot read frame")

                cap.release()

        print("=================================\n")

        return available
    
    def start_camera(self, camera_id):
        """Start a single camera"""
        if camera_id in self.workers:
            return
        
        worker = CameraWorker(camera_id, self.config)
        worker.frame_ready.connect(self.on_frame_ready)
        worker.status_update.connect(self.on_status_update)
        worker.error_occurred.connect(self.on_error)
        worker.start()
        self.workers[camera_id] = worker
        
        if camera_id not in self.active_cameras:
            self.active_cameras.append(camera_id)
    
    def start_all_cameras(self, camera_ids):
        """Start multiple cameras"""
        for cam_id in camera_ids:
            self.start_camera(cam_id)
        
        # Set first camera as primary
        if camera_ids and self.primary_camera_id is None:
            self.primary_camera_id = camera_ids[0]
    
    def stop_camera(self, camera_id):
        """Stop a single camera"""
        if camera_id in self.workers:
            self.workers[camera_id].stop()
            del self.workers[camera_id]
            if camera_id in self.active_cameras:
                self.active_cameras.remove(camera_id)
    
    def stop_all_cameras(self):
        """Stop all cameras"""
        for cam_id in list(self.workers.keys()):
            self.stop_camera(cam_id)
        self.active_cameras = []
        self.primary_camera_id = None
    
    def set_primary_camera(self, camera_id):
        """Set which camera sends data to the dashboard"""
        if camera_id in self.workers:
            self.primary_camera_id = camera_id
    
    def get_frame(self, camera_id):
        """Get the latest frame from a camera"""
        if camera_id in self.workers and self.workers[camera_id].last_frame is not None:
            return self.workers[camera_id].last_frame
        return None
    
    def get_primary_frame(self):
        """Get the latest frame from the primary camera"""

        print("\n========== PRIMARY FRAME DEBUG ==========")
        print(f"primary_camera_id = {self.primary_camera_id}")
        print(f"worker keys = {list(self.workers.keys())}")
        print(f"latest_frames keys = {list(self.latest_frames.keys())}")

        if self.primary_camera_id is not None and self.primary_camera_id in self.workers:
            print("Calling get_frame()...")
            frame = self.get_frame(self.primary_camera_id)

            if frame is None:
                print("get_frame() returned None")
            else:
                print(f"get_frame() returned {frame.shape}")

            return frame

        print("Primary camera not found")
        return None
    
    def on_frame_ready(self, frame, camera_id):
        """Handle frame from worker - store latest frames and throttle multicam processing"""

        self.latest_frames[camera_id] = frame
        print(f"[CameraManager] on_frame_ready camera={camera_id}, latest={list(self.latest_frames.keys())}")

        # Send frame directly to CameraWindow
        if self.camera_window is not None:
            print(f"[CameraManager] ---> sending camera {camera_id}")
            self.camera_window.update_camera(camera_id, frame)

        if len(self.latest_frames) < 2:
            return

        import time

        # Don't start another multicam job while one is running
        if self.processing_multi_cam:
            return

        # Limit multicam processing to about 6-7 FPS
        now = time.time()

        if now - self.last_multi_cam_time < self.multi_cam_interval:
            return

        self.processing_multi_cam = True

        try:
            self.process_multi_camera_frame()
            self.last_multi_cam_time = now
        finally:
            self.processing_multi_cam = False
    
    def on_status_update(self, message, camera_id):
        """Handle status update from worker"""
        print(f"[Camera {camera_id}] {message}")
    
    def on_error(self, error, camera_id):
        """Handle error from worker"""
        print(f"[Camera {camera_id}] ERROR: {error}")

    def process_multi_camera_frame(self):
        """Process frames from all cameras and triangulate player positions"""
        if len(self.latest_frames) < 2:
            return
        
        # Get frames from two cameras
        cam_ids = list(self.latest_frames.keys())[:2]
        frame_left = self.latest_frames.get(cam_ids[0])
        frame_right = self.latest_frames.get(cam_ids[1])
        
        if frame_left is None or frame_right is None:
            return
        
        # Run detection on both frames
        engine = self.workers[cam_ids[0]].engine
        
        # Process detections on both cameras (using same color ranges)
        t1_range = ([0, 100, 100], [10, 255, 255])
        t2_range = ([100, 100, 100], [130, 255, 255])
        
        # Use a small detection interval to avoid heavy load
        westy_left, opp_left, _ = engine._process_detections(frame_left, 0, t1_range, t2_range)
        westy_right, opp_right, _ = engine._process_detections(frame_right, 0, t1_range, t2_range)
        
        # Match players between cameras and triangulate
        all_players_left = westy_left + opp_left
        all_players_right = westy_right + opp_right
        
        matched_3d = []
        for i, playerL in enumerate(all_players_left):
            if i < len(all_players_right):
                playerR = all_players_right[i]
                # Triangulate the center position
                pt_3d = self.triangulator.triangulate_point(
                    (playerL['x'], playerL['y']),
                    (playerR['x'], playerR['y']),
                    cam_ids[0], cam_ids[1]
                )
                if pt_3d:
                    matched_3d.append({
                        'id': playerL['id'],
                        'x': pt_3d[0],
                        'y': pt_3d[1],
                        'z': pt_3d[2],
                        'team': playerL['team']
                    })
        
        self.triangulated_players = matched_3d
        
        if len(matched_3d) > 0:
            print(f"[MultiCam] Triangulated {len(matched_3d)} players in 3D")

    def calibrate_court_3d(self):
        """Calibrate court for 3D mapping using clicked points"""
        print("[3D Calibration] Court dimensions:", self.court_dimensions)
        self.court_dimensions = (28, 15)
        print("[3D Calibration] Using default court dimensions: 28m x 15m")

    def test_triangulation(self):
        """Test triangulation with mock data"""
        print("[Test] Testing triangulation...")
        
        import numpy as np
        
        K = np.array([[1000, 0, 320], [0, 1000, 240], [0, 0, 1]], dtype=np.float32)
        dist = np.zeros(5, dtype=np.float32)
        R = np.eye(3, dtype=np.float32)
        
        T0 = np.array([[0], [0], [0]], dtype=np.float32)
        T1 = np.array([[10], [0], [0]], dtype=np.float32)
        
        if self.triangulator is None:
            from triangulation import Triangulator
            self.triangulator = Triangulator()
        
        self.triangulator.add_camera(0, K, dist, R, T0)
        self.triangulator.add_camera(1, K, dist, R, T1)
        self.triangulator.compute_projection_matrix(0)
        self.triangulator.compute_projection_matrix(1)
        
        point_3d = (5, 0, 0)
        print(f"[Test] Mock 3D point: {point_3d}")
        
        return True